/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package empreg;

import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import net.proteanit.sql.DbUtils;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author User
 */
public class EMPREG1 extends javax.swing.JFrame {

    Statement st;
    ResultSet rs=null;
    PreparedStatement pst=null;
    Connection con=null;
    String filename=null;
    private byte[] person_image=null;
    private ImageIcon format=null;
    String s;
    int pos=0;
    
    
    
    public EMPREG1() {
        initComponents();
        showTableData();
        
       //ShowusersInjtable();
    }
    String Imagepath=null;
    /* public Connection getConncetion() throws SQLException{
            
            Connection con;
            try{
                Class.forName("com.mysql.jdbc.Driver");
                con=DriverManager.getConnection("jdbc:mysql://localhost:3306/empr","root","1234");
                return con;
            } catch(Exception e){
                e.printStackTrace();
                return null;
            }
            
            
        }
        public ArrayList<User> getUsersList(){
            
            ArrayList<User> userList=new ArrayList<User>();
            Connection connection= getConnection();
            String query= "SELECT * FROM `ern`";
            Statement st;
            ResultSet rs;
            
            try{
                st=connection.createStatement();
                rs=st.executeQuery(query);
                User user;
                while(rs.next()){
                    user=new User (rs.getString("pid"),rs.getString("pname"),rs.getString("empid"),rs.getString("fname"),rs.getString("lname"),rs.getString("cno"));
                    userList.add(user);
                }
            }catch(Exception e){
                e.printStackTrace();
            }
            return userList;
            
        }
        public void ShowusersInjtable(){
            
            ArrayList<User>list=getUsersList();
            DefaultTableModel model=(DefaultTableModel)jTable1.getModel();
            Object [] row=new Object[6];
            for(int i=0;i<list.size();i++){
            
        
            row[0]=list.get(i).getPid();
            row[1]=list.get(i).getPname();
            row[2]=list.get(i).getEmpid();
            row[3]=list.get(i).getFname();
            row[4]=list.get(i).getLname();
            row[5]=list.get(i).getCno();
            
            model.addRow(row);
            }
            
        }*/
       
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox2 = new javax.swing.JComboBox();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        button2 = new java.awt.Button();
        button1 = new java.awt.Button();
        update = new java.awt.Button();
        Delete = new java.awt.Button();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        pname = new javax.swing.JTextField();
        pid = new javax.swing.JTextField();
        eid = new javax.swing.JTextField();
        status = new javax.swing.JComboBox();
        fname = new javax.swing.JTextField();
        lname = new javax.swing.JTextField();
        ad = new javax.swing.JTextField();
        nno = new javax.swing.JTextField();
        cno = new javax.swing.JTextField();
        pot = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        image1 = new javax.swing.JLabel();
        Browse = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel61 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        Printpdf = new javax.swing.JButton();
        Printexcel = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        image2 = new javax.swing.JLabel();
        serachtext = new javax.swing.JTextField();
        butserach = new javax.swing.JButton();

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jTable1.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PNAME", "PID", "EID", "STATUS", "FNAME", "LANME", "ADDRESS", "NICNO", "CNO", "POSTION"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable1KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTable1KeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 665, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        button2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        button2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        button2.setLabel("Register");
        button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button2ActionPerformed(evt);
            }
        });

        button1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        button1.setLabel("Reset");
        button1.setName(""); // NOI18N
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });

        update.setActionCommand("update");
        update.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        update.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        update.setLabel("Update");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        Delete.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        Delete.setLabel("Delete");
        Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Delete, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(update, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(button2, javax.swing.GroupLayout.DEFAULT_SIZE, 97, Short.MAX_VALUE)
                        .addComponent(button1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(49, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(button2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(button1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(update, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19)
                .addComponent(Delete, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setText("REGISTER FORM");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jLabel2.setText("Project Name");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jLabel3.setText("Project ID");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jLabel4.setText("Employee ID");

        jLabel11.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jLabel11.setText("Status");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jLabel6.setText("First Name");

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jLabel7.setText("Last Name");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jLabel5.setText("Address");

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jLabel8.setText("Nic No");

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jLabel9.setText("Contact No");

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jLabel10.setText("Position");

        pname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pnameActionPerformed(evt);
            }
        });

        status.setEditable(true);
        status.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Mr", "Ms", "Mrs", "Miss" }));
        status.setToolTipText("");

        ad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adActionPerformed(evt);
            }
        });

        cno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cnoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(9, 9, 9))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(22, 22, 22))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(fname, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(status, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(eid, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(82, 82, 82)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel7))
                                .addGap(29, 29, 29))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel8))
                                .addGap(26, 26, 26))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(pid, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addComponent(pname, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(166, 166, 166))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(cno, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 247, Short.MAX_VALUE)
                    .addComponent(lname, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ad, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(nno, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pot))
                .addContainerGap(65, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(278, 278, 278)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(26, 26, 26)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(pname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(pid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(eid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(status, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11)
                            .addComponent(jLabel9))
                        .addGap(18, 18, 18))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(ad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(nno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(fname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6)
                        .addComponent(jLabel10))
                    .addComponent(pot, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14))
        );

        jPanel4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel12.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        jLabel12.setText("EmpImage");

        image1.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        image1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        Browse.setText("Browse");
        Browse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BrowseActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(103, 103, 103)
                .addComponent(jLabel12)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(109, 109, 109)
                .addComponent(Browse)
                .addContainerGap(99, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(image1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(image1, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Browse))
        );

        jPanel5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel61.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel61.setText("LastName");

        jLabel64.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel64.setText("ContactNo");

        jLabel62.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel62.setText("Address");

        jLabel57.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel57.setText("Project ID");

        jLabel63.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel63.setText("NicNo");

        jLabel59.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel59.setText("Status");

        jLabel58.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel58.setText("Employee ID");

        jLabel56.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel56.setText("Project Name");

        jLabel60.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel60.setText("FirstName");

        jLabel65.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel65.setText("Position");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel56, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel57, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel58, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel62, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel63, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel64, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel65, javax.swing.GroupLayout.PREFERRED_SIZE, 324, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel59, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel60, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel61, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(96, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(jLabel56)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel57)
                .addGap(18, 18, 18)
                .addComponent(jLabel58)
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel59)
                    .addComponent(jLabel60)
                    .addComponent(jLabel61))
                .addGap(18, 18, 18)
                .addComponent(jLabel62)
                .addGap(18, 18, 18)
                .addComponent(jLabel63)
                .addGap(18, 18, 18)
                .addComponent(jLabel64)
                .addGap(18, 18, 18)
                .addComponent(jLabel65)
                .addGap(0, 32, Short.MAX_VALUE))
        );

        Printpdf.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        Printpdf.setText("Print PDF");
        Printpdf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PrintpdfActionPerformed(evt);
            }
        });

        Printexcel.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        Printexcel.setText("Print Excel");
        Printexcel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PrintexcelActionPerformed(evt);
            }
        });

        jPanel7.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        image2.setFont(new java.awt.Font("Times New Roman", 1, 11)); // NOI18N
        image2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(image2, javax.swing.GroupLayout.DEFAULT_SIZE, 288, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(image2, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45))
        );

        serachtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                serachtextActionPerformed(evt);
            }
        });

        butserach.setText("Search");
        butserach.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butserachActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Printexcel, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(129, 129, 129)
                        .addComponent(Printpdf, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(144, 144, 144)
                .addComponent(serachtext, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(57, 57, 57)
                .addComponent(butserach, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(butserach, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
                    .addComponent(serachtext, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Printexcel, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Printpdf, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(14, 14, 14))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(71, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void button2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button2ActionPerformed

	try {          
       
        String Pname=pname.getText().toString();
        String Pid=pid.getText().toString();
        String Eid=eid.getText().toString();
        String Fname=fname.getText().toString();
        String Lname=lname.getText().toString();
        String Ad=ad.getText().toString();
        String Nno=nno.getText().toString();
        String Status=status.getEditor().toString(); 
        String Cno=cno.getText().toString();
        String Pot=pot.getText().toString();
       // byte[] Imge=image1.getImage();

        if(Nno.length()>10){
            JOptionPane.showMessageDialog(null, "Nic No incorrect");
        }   
            
        if(Pname.equals("")){
            JOptionPane.showMessageDialog(null, "Project Name Incompleted");
        }
        if(Pid.equals("")){
            JOptionPane.showMessageDialog(null, "Project ID Incompleted");
        }
        if(Eid.equals("")){
            JOptionPane.showMessageDialog(null, "Employee ID Incompleted");
        }
        if(Fname.equals("")){
            JOptionPane.showMessageDialog(null, "First Name Incompleted");
        }
        if(Lname.equals("")){
            JOptionPane.showMessageDialog(null, "Last Name Incompleted");
        }
        if(Ad.equals("")){
            JOptionPane.showMessageDialog(null, "Address Incompleted");
        }
        if(Nno.equals("")){
            JOptionPane.showMessageDialog(null, "Nic No Incompleted");
        }
        if(Status.equals("")){
            JOptionPane.showMessageDialog(null, "Status Incompleted");
        }
       
        if(Cno.equals("")){
            JOptionPane.showMessageDialog(null, "Contact Number Incompleted");
        }
        if(Pot.equals("")){
            JOptionPane.showMessageDialog(null, "Position Incompleted"); 
        }       
       
        else{   
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/empr","root","1234");
            String query="insert into ern(proname,proid,empid,sta,fname,lname,addre,nicn,cno,posit,images)values(?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement pst= con.prepareStatement(query);
            pst.setString(1,pname.getText());
            pst.setString(2,pid.getText());
            pst.setString(3,eid.getText());
            String stat;
            stat=status.getSelectedItem().toString();
            pst.setString(4,stat);
            pst.setString(5,fname.getText());
            pst.setString(6,lname.getText());
            pst.setString(7,ad.getText());
            pst.setString(8,nno.getText());
            pst.setString(9,cno.getText());
            pst.setString(10,pot.getText());  
            pst.setBytes(11,person_image);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null,"Insert Sucessfully");
             showTableData();
        }
        } catch (Exception e) {
             JOptionPane.showMessageDialog(null, e);    
            
       }
    }//GEN-LAST:event_button2ActionPerformed
   
    private void pnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pnameActionPerformed

    private void cnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cnoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cnoActionPerformed

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed

        pname.setText(null);
        pid.setText(null);
        eid.setText(null);
        fname.setText(null);
        lname.setText(null);
        ad.setText(null);
        nno.setText(null);
        cno.setText(null);
        pot.setText(null);
        image1.setUI(null);
      
    }//GEN-LAST:event_button1ActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
        // TODO add your handling code here:
        try {  
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/empr","root","1234");
            String query="UPDATE ern SET proname=?,proid=?,sta=?,fname=?,lname=?,addre=?,nicn=?,cno=?,posit=?,images=? WHERE empid=?";
            PreparedStatement pst= con.prepareStatement(query);
            InputStream fis=new FileInputStream(new File(filename));
            pst.setString(11,eid.getText());
            pst.setString(1,pname.getText());
            pst.setString(2,pid.getText());
            String stat;
            stat=status.getSelectedItem().toString();
            pst.setString(3,stat);
            pst.setString(4,fname.getText());
            pst.setString(5,lname.getText());
            pst.setString(6,ad.getText());
            pst.setString(7,nno.getText());
            pst.setString(8,cno.getText());
            pst.setString(9,pot.getText());  
            pst.setBlob(10,fis);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null,"Update Sucessfully");
            showTableData();
            
        } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);}
        
        
    }//GEN-LAST:event_updateActionPerformed

    private void DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteActionPerformed
        try {  
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/empr","root","1234");
            String query="DELETE FROM ern WHERE empid=?" ;
            PreparedStatement pst= con.prepareStatement(query);
            pst.setString(1,eid.getText());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null,"Delete Sucessfully");
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        
        }
       showTableData();
    }//GEN-LAST:event_DeleteActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        try{
        int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel(); 
        pname.setText(model.getValueAt(i,0).toString());
        pid.setText(model.getValueAt(i,1).toString());
        eid.setText(model.getValueAt(i,2).toString());
        String status1=model.getValueAt(i,3).toString();
        switch(status1){
            case"Mr":
            status.setSelectedIndex(0);
            break;
            case"Ms":
            status.setSelectedIndex(1);
            break;
            case"Mrs":
            status.setSelectedIndex(2);
            break;
            case"Miss":
            status.setSelectedIndex(3);
            break;
        }  
        fname.setText(model.getValueAt(i,4).toString());
        lname.setText(model.getValueAt(i,5).toString());
        ad.setText(model.getValueAt(i,6).toString());
        nno.setText(model.getValueAt(i,7).toString());
        cno.setText(model.getValueAt(i,8).toString());
        pot.setText(model.getValueAt(i,9).toString()); 
        byte[] byteArray = (byte[]) jTable1.getValueAt(i,10);
        ByteArrayInputStream bais = new ByteArrayInputStream(byteArray);
        BufferedImage bImg = ImageIO.read(bais);
        ImageIcon icon = new ImageIcon((bImg).getScaledInstance(241,160,Image.SCALE_SMOOTH));
        image1.setIcon(icon);
        image2.setIcon(icon);
        bais.close();
  
        
        jLabel56.setText(model.getValueAt(i,0).toString());
        jLabel57.setText(model.getValueAt(i,1).toString());
        jLabel58.setText(model.getValueAt(i,2).toString());
        String status2=model.getValueAt(i,3).toString();
        switch(status2){
            case"Mr":
           status.setSelectedIndex(0);
            break;
            case"Ms":
            status.setSelectedIndex(1);
            break;
            case"Mrs":
            status.setSelectedIndex(2);
            break;
            case"Miss":
            status.setSelectedIndex(3);
            break;
            }
        jLabel59.setText(model.getValueAt(i,3).toString());
        jLabel60.setText(model.getValueAt(i,4).toString());
        jLabel61.setText(model.getValueAt(i,5).toString());
        jLabel62.setText(model.getValueAt(i,6).toString());
        jLabel63.setText(model.getValueAt(i,7).toString());
        jLabel64.setText(model.getValueAt(i,8).toString());
        jLabel65.setText(model.getValueAt(i,9).toString());  
        
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
       
    }//GEN-LAST:event_jTable1MouseClicked
 
    private void BrowseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BrowseActionPerformed
        // TODO add your handling code here:
        JFileChooser chooser=new JFileChooser();
        chooser.showOpenDialog(null);
        File f=chooser.getSelectedFile();
        filename=f.getAbsolutePath();
        ImageIcon imageIcon=new ImageIcon(new ImageIcon(filename).getImage().getScaledInstance(241,160,Image.SCALE_SMOOTH) );
        image1.setIcon(imageIcon);
        try{
           File image=new File(filename);
           FileInputStream fis=new FileInputStream(image);
            ByteArrayOutputStream bos=new ByteArrayOutputStream();
            byte[] buf= new byte[1024];
            for(int readNum;(readNum=fis.read(buf))!=-1;){
                bos.write(buf,0,readNum);
            }
            person_image=bos.toByteArray();          
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
                        
        }
               
    }//GEN-LAST:event_BrowseActionPerformed

    private void adActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_adActionPerformed

    private void PrintexcelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PrintexcelActionPerformed
        // TODO add your handling code here:
       try{
       Class.forName("com.mysql.jdbc.Driver");
       Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/empr","root","1234");
       String sql="SELECT * FROM ern ";
       pst= con.prepareStatement(sql);
       rs=pst.executeQuery(sql);
        
        XSSFWorkbook wb= new XSSFWorkbook();
        XSSFSheet sheet=wb.createSheet("RegisterDetails");
        XSSFRow header=sheet.createRow(0);
        header.createCell(0).setCellValue("projectName");
        header.createCell(1).setCellValue("projectId");
        header.createCell(2).setCellValue("empId");
        header.createCell(3).setCellValue("status");
        header.createCell(4).setCellValue("firstName");
        header.createCell(5).setCellValue("lastName");
        header.createCell(6).setCellValue("address");
        header.createCell(7).setCellValue("nicNo");
        header.createCell(8).setCellValue("contactNo");
        header.createCell(9).setCellValue("position");
        header.createCell(10).setCellValue("images");
               
         FileOutputStream fileout=new  FileOutputStream("RegisterDetails.xlsx");
         wb.write(fileout);
         JOptionPane.showMessageDialog(null,"Succesfully Export to Excel");
         fileout.close();            
         pst.close();
         rs.close();              
        }catch(Exception e){
           JOptionPane.showMessageDialog(null,e);
        }
        
        
    }//GEN-LAST:event_PrintexcelActionPerformed

    private void PrintpdfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PrintpdfActionPerformed
        // TODO add your handling code here:
        MessageFormat header=new MessageFormat("Register Employee Details");
        MessageFormat footer=new MessageFormat("Page(0,number,intger)");
        
        try{
            jTable1.print(JTable.PrintMode.NORMAL,header, footer);
        }catch(Exception e){
             e.printStackTrace();
        }
        
        
        
    }//GEN-LAST:event_PrintpdfActionPerformed

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:
        try{
        if(evt.getKeyCode()==KeyEvent.VK_DOWN ||evt.getKeyCode()==KeyEvent.VK_UP){
           int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel(); 
        pname.setText(model.getValueAt(i,0).toString());
        pid.setText(model.getValueAt(i,1).toString());
        eid.setText(model.getValueAt(i,2).toString());
        String status1=model.getValueAt(i,3).toString();
        switch(status1){
            case"Mr":
            status.setSelectedIndex(0);
            break;
            case"Ms":
            status.setSelectedIndex(1);
            break;
            case"Mrs":
            status.setSelectedIndex(2);
            break;
            case"Miss":
            status.setSelectedIndex(3);
            break;
        }  
        fname.setText(model.getValueAt(i,4).toString());
        lname.setText(model.getValueAt(i,5).toString());
        ad.setText(model.getValueAt(i,6).toString());
        nno.setText(model.getValueAt(i,7).toString());
        cno.setText(model.getValueAt(i,8).toString());
        pot.setText(model.getValueAt(i,9).toString());  
        byte[] byteArray = (byte[]) jTable1.getValueAt(i,10);
        ByteArrayInputStream bais = new ByteArrayInputStream(byteArray);
        BufferedImage bImg = ImageIO.read(bais);
        ImageIcon icon = new ImageIcon((bImg).getScaledInstance(241,160,Image.SCALE_SMOOTH));
        image1.setIcon(icon);
        image2.setIcon(icon);
        bais.close();
        
        jLabel56.setText(model.getValueAt(i,0).toString());
        jLabel57.setText(model.getValueAt(i,1).toString());
        jLabel58.setText(model.getValueAt(i,2).toString());
        String status2=model.getValueAt(i,3).toString();
        switch(status2){
            case"Mr":
           status.setSelectedIndex(0);
            break;
            case"Ms":
            status.setSelectedIndex(1);
            break;
            case"Mrs":
            status.setSelectedIndex(2);
            break;
            case"Miss":
            status.setSelectedIndex(3);
            break;
            }
        jLabel59.setText(model.getValueAt(i,3).toString());
        jLabel60.setText(model.getValueAt(i,4).toString());
        jLabel61.setText(model.getValueAt(i,5).toString());
        jLabel62.setText(model.getValueAt(i,6).toString());
        jLabel63.setText(model.getValueAt(i,7).toString());
        jLabel64.setText(model.getValueAt(i,8).toString());
        jLabel65.setText(model.getValueAt(i,9).toString()); 
        }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex);;
        }
        
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyReleased
        // TODO add your handling code here:
        try{
        if(evt.getKeyCode()==KeyEvent.VK_DOWN ||evt.getKeyCode()==KeyEvent.VK_UP){
         int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel(); 
        pname.setText(model.getValueAt(i,0).toString());
        pid.setText(model.getValueAt(i,1).toString());
        eid.setText(model.getValueAt(i,2).toString());
        String status1=model.getValueAt(i,3).toString();
        switch(status1){
            case"Mr":
            status.setSelectedIndex(0);
            break;
            case"Ms":
            status.setSelectedIndex(1);
            break;
            case"Mrs":
            status.setSelectedIndex(2);
            break;
            case"Miss":
            status.setSelectedIndex(3);
            break;
        }  
        fname.setText(model.getValueAt(i,4).toString());
        lname.setText(model.getValueAt(i,5).toString());
        ad.setText(model.getValueAt(i,6).toString());
        nno.setText(model.getValueAt(i,7).toString());
        cno.setText(model.getValueAt(i,8).toString());
        pot.setText(model.getValueAt(i,9).toString());  
        byte[] byteArray = (byte[]) jTable1.getValueAt(i,10);
        ByteArrayInputStream bais = new ByteArrayInputStream(byteArray);
        BufferedImage bImg = ImageIO.read(bais);
        ImageIcon icon = new ImageIcon((bImg).getScaledInstance(241,160,Image.SCALE_SMOOTH));
        image1.setIcon(icon);
        image2.setIcon(icon);
        bais.close();
        
        jLabel56.setText(model.getValueAt(i,0).toString());
        jLabel57.setText(model.getValueAt(i,1).toString());
        jLabel58.setText(model.getValueAt(i,2).toString());
        String status2=model.getValueAt(i,3).toString();
        switch(status2){
            case"Mr":
           status.setSelectedIndex(0);
            break;
            case"Ms":
            status.setSelectedIndex(1);
            break;
            case"Mrs":
            status.setSelectedIndex(2);
            break;
            case"Miss":
            status.setSelectedIndex(3);
            break;
            }
        jLabel59.setText(model.getValueAt(i,3).toString());
        jLabel60.setText(model.getValueAt(i,4).toString());
        jLabel61.setText(model.getValueAt(i,5).toString());
        jLabel62.setText(model.getValueAt(i,6).toString());
        jLabel63.setText(model.getValueAt(i,7).toString());
        jLabel64.setText(model.getValueAt(i,8).toString());
        jLabel65.setText(model.getValueAt(i,9).toString());   
        }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex);;
        }
    }//GEN-LAST:event_jTable1KeyReleased

    private void serachtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_serachtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_serachtextActionPerformed

    private void butserachActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butserachActionPerformed
        // TODO add your handling code here:
       
       try{
       Class.forName("com.mysql.jdbc.Driver");
       Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/empr","root","1234");
       String sql="SELECT * FROM ern WHERE empid=?";
       pst= con.prepareStatement(sql);
       pst.setString(1,serachtext.getText());
       rs=pst.executeQuery();
       if(rs.next()){
            serachlabeldetails();
       }
       }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        
            }
        }
    
      private void serachlabeldetails(){
               
          try{
               pname.setText(rs.getString("proname"));
               pid.setText(rs.getString("proid"));
               eid.setText(rs.getString("empid"));
               status.setSelectedItem(rs.getString("sta"));
               fname.setText(rs.getString("fname"));
               lname.setText(rs.getString("lname"));
               ad.setText(rs.getString("addre"));
               nno.setText(rs.getString("nicn"));
               cno.setText(rs.getString("cno"));
               pot.setText(rs.getString("posit"));
              // image1.imageUpdate(rs.getString("images"));
                 
               jLabel56.setText(rs.getString("proname"));
               jLabel57.setText(rs.getString("proid"));
               jLabel58.setText(rs.getString("empid"));  
               jLabel59.setText(rs.getString("sta"));
               jLabel60.setText(rs.getString("fname"));
               jLabel61.setText(rs.getString("lname"));
               jLabel62.setText(rs.getString("addre"));
               jLabel63.setText(rs.getString("nicn"));
               jLabel64.setText(rs.getString("cno"));
               jLabel65.setText(rs.getString("posit"));
                 
                byte[] byteArray = (byte[])(rs.getBytes("images"));
                ByteArrayInputStream bais = new ByteArrayInputStream(byteArray);
                BufferedImage bImg = ImageIO.read(bais);
                ImageIcon icon = new ImageIcon((bImg).getScaledInstance(241,160,Image.SCALE_SMOOTH));
                image1.setIcon(icon);
                image2.setIcon(icon);
                
          }catch(Exception e){
               JOptionPane.showMessageDialog(null, e);
          }
    }//GEN-LAST:event_butserachActionPerformed

      public void showTableData(){

        try {  
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/empr","root","1234");
            String sql="SELECT * FROM ern";
            pst= con.prepareStatement(sql);
            rs=pst.executeQuery();
            jTable1.setModel(DbUtils.resultSetToTableModel(rs));
    }catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex);
    }
  }
        
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EMPREG1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EMPREG1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EMPREG1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EMPREG1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EMPREG1().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Browse;
    private java.awt.Button Delete;
    private javax.swing.JButton Printexcel;
    private javax.swing.JButton Printpdf;
    private javax.swing.JTextField ad;
    private javax.swing.JButton butserach;
    private java.awt.Button button1;
    private java.awt.Button button2;
    private javax.swing.JTextField cno;
    private javax.swing.JTextField eid;
    private javax.swing.JTextField fname;
    private javax.swing.JLabel image1;
    private javax.swing.JLabel image2;
    private javax.swing.JComboBox jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField lname;
    private javax.swing.JTextField nno;
    private javax.swing.JTextField pid;
    private javax.swing.JTextField pname;
    private javax.swing.JTextField pot;
    private javax.swing.JTextField serachtext;
    private javax.swing.JComboBox status;
    private java.awt.Button update;
    // End of variables declaration//GEN-END:variables

    private Connection getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private String scaledImage(byte[] imageData, int width, int height) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private Icon Resizeimage(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
