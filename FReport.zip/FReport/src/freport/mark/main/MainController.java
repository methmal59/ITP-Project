
package freport.mark.main;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;
import javafx.stage.StageStyle;


public class MainController implements Initializable {

    @FXML
    private PieChart incomePie;
    @FXML
    private PieChart expensesPie;
    @FXML
    private PieChart totalPie;
    
    @FXML
    private BarChart<?, ?> comparatorChart;
    @FXML
    private NumberAxis yAxis;
    @FXML
    private CategoryAxis xAxis;
    
    @FXML
    private LineChart<?, ?> positionChart;
    @FXML
    private NumberAxis yfAxis;
    @FXML
    private CategoryAxis xfAxis;


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ObservableList<PieChart.Data> incomePieData
                =FXCollections.observableArrayList(
                 new PieChart.Data("Project Sales",20),
                 new PieChart.Data("Other",30),
                 new PieChart.Data("Advance Payment",15));
        
        incomePie.setData(incomePieData);
        incomePie.setStartAngle(90);
        //incomePie testing..................
        
        ObservableList<PieChart.Data> expensesPieData
                =FXCollections.observableArrayList(
                 new PieChart.Data("Tax",10),
                 new PieChart.Data("Other",20),
                 new PieChart.Data("Marketing",5));
        
        expensesPie.setData(expensesPieData);
        expensesPie.setStartAngle(90);
        //expensesPie testing.....................
        
        ObservableList<PieChart.Data> totalPieData
                =FXCollections.observableArrayList(
                 new PieChart.Data("TIncome",40),
                 new PieChart.Data("TExpenses",10),
                 new PieChart.Data("TProfit",10));
        
        totalPie.setData(totalPieData);
        totalPie.setStartAngle(90);
        //totalPie testing........................
        
        //////////////////////////////////////////////////////
        
        XYChart.Series set1 = new XYChart.Series<>();
        set1.setName("Income");
        set1.getData().add(new XYChart.Data("January",5000));
        set1.getData().add(new XYChart.Data("February",10000));
        set1.getData().add(new XYChart.Data("March",9000));
        set1.getData().add(new XYChart.Data("April",7000));
        set1.getData().add(new XYChart.Data("May",12000));
        
        
        comparatorChart.getData().addAll(set1);
        
        XYChart.Series set2 = new XYChart.Series<>();
        set2.setName("Expenses");
        set2.getData().add(new XYChart.Data("January",1000));
        set2.getData().add(new XYChart.Data("February",3000));
        set2.getData().add(new XYChart.Data("March",2000));
        set2.getData().add(new XYChart.Data("April",7000));
        set2.getData().add(new XYChart.Data("May",6000));
        
        
        comparatorChart.getData().addAll(set2);
        //comparatorchart testing............................
        
        //////////////////////////////////////////////////////
        
        XYChart.Series series = new XYChart.Series();
        series.setName("Net Profit");
        series.getData().add(new XYChart.Data("January",6000));
        series.getData().add(new XYChart.Data("February",10000));
        series.getData().add(new XYChart.Data("March",12500));
        series.getData().add(new XYChart.Data("April",8500));
        series.getData().add(new XYChart.Data("May",9500));
        series.getData().add(new XYChart.Data("June",3800));
        series.getData().add(new XYChart.Data("July",2100));
        series.getData().add(new XYChart.Data("August",6600));
        positionChart.getData().addAll(series);
    }    

    @FXML
    private void loadAddIncome(ActionEvent event) {
        loadWindow("/freport/mark/i/FXMLDocument.fxml", "Add New Income");
    }

    @FXML
    private void loadViewIncome(ActionEvent event) {
        loadWindow("/freport/mark/listincome/income_list.fxml", "Income List");
    }

    @FXML
    private void loadAddExpense(ActionEvent event) {
        loadWindow("/freport/mark/e/expense_add.fxml", "Add New Expense");
    }

    @FXML
    private void loadViewExpenses(ActionEvent event) {
        loadWindow("/freport/mark/listexpenses/Expenses_list.fxml", "Expenses List");
    }

    @FXML
    private void loadPrintReport(ActionEvent event) {
    }

    @FXML
    private void loadSendReport(ActionEvent event) {
    }
    
      
    void loadWindow(String loc, String title){
    
        try {
            Parent parent = FXMLLoader.load(getClass().getResource(loc) );
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle(title);
            stage.setScene(new Scene(parent));
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(MainController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
