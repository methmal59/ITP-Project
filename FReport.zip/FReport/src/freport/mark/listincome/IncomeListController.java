
package freport.mark.listincome;

import freport.mark.database.dataBaseHandler;
import freport.mark.i.FXMLDocumentController;
import freport.mark.main.MainController;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;


public class IncomeListController implements Initializable {
    
    ObservableList<Income> list = FXCollections.observableArrayList();

    @FXML
    private AnchorPane rootPane;
    @FXML
    private TableView<Income> tableView;
    @FXML
    private TableColumn<Income, String> idCol;
    @FXML
    private TableColumn<Income, String> dateCol;
    @FXML
    private TableColumn<Income, String> categoryCol;
    @FXML
    private TableColumn<Income, String> amountCol;

  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initCol();
        loadData();
    }   

    private void initCol() {
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));
        categoryCol.setCellValueFactory(new PropertyValueFactory<>("category"));
        amountCol.setCellValueFactory(new PropertyValueFactory<>("amount"));
    }

    private void loadData() {
        list.clear();
        
        dataBaseHandler handler = dataBaseHandler.getInstance();
        String qu = "SELECT * FROM INCOME";
        ResultSet rs = handler.execQuery(qu);
        try {
            while(rs.next()){
                String id = rs.getString("id");
                String date = rs.getString("date");
                String category = rs.getString("category");
                String amount = rs.getString("amount");
                
                list.add(new Income(id, date, category, amount));
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        tableView.setItems(list);
    }

    @FXML
    private void deleteIncome(ActionEvent event) {
        
        Income selectedForDeletion = tableView.getSelectionModel().getSelectedItem();
        if(selectedForDeletion == null){
            Alert alert1 = new Alert(Alert.AlertType.ERROR);
            alert1.setTitle("No Income Selected");
            alert1.setContentText("Please Select a Income For Delete.");
            return;
        }
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Deleting Income");
        alert.setContentText("Are you sure want to delete the income " + selectedForDeletion.getCategory() + " ?" );
        Optional<ButtonType> answer = alert.showAndWait();
        if(answer.get() == ButtonType.OK){
           Boolean result = dataBaseHandler.getInstance().deleteIncome(selectedForDeletion);
           if(result){
              
                Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                alert1.setTitle("Income deleted");
                alert1.setContentText(selectedForDeletion.getCategory() + "was deleted successfully.");
                list.remove(selectedForDeletion);
           }
           else{
               Alert alert2 = new Alert(Alert.AlertType.ERROR);
               alert2.setTitle("Failed");
               alert2.setHeaderText(selectedForDeletion.getCategory() + "could not be deleted.");
           }
        }
        else{
 
            Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
            alert1.setTitle("Deletion Cancelled");
            alert1.setContentText("Deletion Process Cancelled.");
        }
    }

    @FXML
    private void editIncome(ActionEvent event) {
        Income selectedForEdit = tableView.getSelectionModel().getSelectedItem();
        if(selectedForEdit == null){
            Alert alert1 = new Alert(Alert.AlertType.ERROR);
            alert1.setTitle("No Income Selected");
            alert1.setContentText("Please Select a Income For Edit.");
            return;
        }
        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/freport/mark/i/FXMLDocument.fxml"));
            Parent parent = loader.load();
            
            FXMLDocumentController controller = (FXMLDocumentController)loader.getController();
            controller.inflateUI(selectedForEdit);
            
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle("Edit Income");
            stage.setScene(new Scene(parent));
            stage.show();
            
            stage.setOnCloseRequest((e)-> {
                refreshIncome(new ActionEvent());
            });
            
        } catch (IOException ex) {
            Logger.getLogger(MainController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }

    @FXML
    private void refreshIncome(ActionEvent event) {
        loadData(); 
    }
    
    public static class Income{
        private final SimpleStringProperty id;
        private final SimpleStringProperty date;
        private final SimpleStringProperty category;
        private final SimpleStringProperty amount;
        
        public Income(String id, String date, String category, String amount){
                this.id = new SimpleStringProperty(id);
                this.date = new SimpleStringProperty(date);
                this.category = new SimpleStringProperty(category);
                this.amount = new SimpleStringProperty(amount);
        }

        public String getId() {
            return id.get();
        }

        public String getDate() {
            return date.get();
        }

        public String getCategory() {
            return category.get();
        }

        public String getAmount() {
            return amount.get();
        }
        
        
    }
    
}
