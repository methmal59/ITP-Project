
package freport.mark.listexpenses;

import freport.mark.database.dataBaseHandler;
import freport.mark.e.ExpenseAddController;
import freport.mark.i.FXMLDocumentController;
import freport.mark.main.MainController;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;


public class ExpensesListController implements Initializable {
    
    ObservableList<Expense> list = FXCollections.observableArrayList();

    @FXML
    private TableView<Expense> etableView;
    @FXML
    private TableColumn<Expense, String> eidCol;
    @FXML
    private TableColumn<Expense, String> edateCol;
    @FXML
    private TableColumn<Expense, String> ecategoryCol;
    @FXML
    private TableColumn<Expense, String> eamountCol;

   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initCol();
        loadData();
    }    
    
    private void initCol() {
        eidCol.setCellValueFactory(new PropertyValueFactory<>("eid"));
        edateCol.setCellValueFactory(new PropertyValueFactory<>("edate"));
        ecategoryCol.setCellValueFactory(new PropertyValueFactory<>("ecategory"));
        eamountCol.setCellValueFactory(new PropertyValueFactory<>("eamount"));
    }
    
     private void loadData() {
        list.clear();
         
        dataBaseHandler handler = dataBaseHandler.getInstance();
        String qu = "SELECT * FROM EXPENSE";
        ResultSet rs = handler.execQuery(qu);
        try {
            while(rs.next()){
                String eid = rs.getString("eid");
                String edate = rs.getString("edate");
                String ecategory = rs.getString("ecategory");
                String eamount = rs.getString("eamount");
                
                list.add(new Expense(eid, edate, ecategory, eamount));
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        etableView.setItems(list);
     }

    @FXML
    private void deleteExpense(ActionEvent event) {
        Expense selectedForDeletion = etableView.getSelectionModel().getSelectedItem();
        if(selectedForDeletion == null){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No Expense Selected");
            alert.setContentText("Please Select a Expense For Delete." );
            return;
        }
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Deleting Expense");
        alert.setContentText("Are you sure want to delete the expense " + selectedForDeletion.getEcategory() + " ?" );
        Optional<ButtonType> answer = alert.showAndWait();
        if(answer.get() == ButtonType.OK){
           Boolean result = dataBaseHandler.getInstance().deleteExpense(selectedForDeletion);
           if(result){    
               Alert alert1 = new Alert(Alert.AlertType.ERROR);
               alert1.setTitle("Expense deleted");
               alert1.setContentText(selectedForDeletion.getEcategory() + "was deleted successfully.");
               list.remove(selectedForDeletion);
           }
           else{
               Alert alert1 = new Alert(Alert.AlertType.ERROR);
               alert1.setTitle("Failed");
               alert1.setContentText("Failed" + selectedForDeletion.getEcategory() + "could not be deleted.");
           }
        }
        else{
            Alert alert1 = new Alert(Alert.AlertType.ERROR);
            alert1.setTitle("Deletion Cancelled");
            alert1.setContentText("Deletion Process Cancelled.");
        }
    }

    @FXML
    private void refreshExpense(ActionEvent event) {
        loadData();
    }

    @FXML
    private void editExpense(ActionEvent event) {
        Expense selectedForEdit = etableView.getSelectionModel().getSelectedItem();
        
        
        if(selectedForEdit == null){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No Expense Selected");
            alert.setContentText("Please Select a Expense For Edit." );
            return;
        }
        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/freport/mark/e/expense_add.fxml"));
            Parent parent = loader.load();
            
            ExpenseAddController controller = (ExpenseAddController)loader.getController();
            System.out.println("a2");
            controller.inflateUI(selectedForEdit);
            System.out.println("a1");
            Stage stage = new Stage(StageStyle.DECORATED);
            System.out.println("a");
            stage.setTitle("Edit Income");
            stage.setScene(new Scene(parent));
            stage.show();
            
            stage.setOnCloseRequest((e)-> {
                refreshExpense(new ActionEvent());
            });
            
        } catch (IOException ex) {
            Logger.getLogger(MainController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception e){
            e.printStackTrace();
        }
    }
    
    
    
    public static class Expense{
        
        private final SimpleStringProperty eid;
        private final SimpleStringProperty edate;
        private final SimpleStringProperty ecategory;
        private final SimpleStringProperty eamount;
        
        public Expense(String eid, String edate, String ecategory, String eamount){
            this.eid = new SimpleStringProperty(eid);
            this.edate = new SimpleStringProperty(edate);
            this.ecategory = new SimpleStringProperty(ecategory);
            this.eamount = new SimpleStringProperty(eamount);
            
        }

        public String getEid() {
            return eid.get();
        }

        public String getEdate() {
            return edate.get();
        }

        public String getEcategory() {
            return ecategory.get();
        }

        public String getEamount() {
            return eamount.get();
        }
        
        
    }
    
}
