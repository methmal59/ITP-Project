
package freport.mark.i;

import freport.mark.database.dataBaseHandler;
import freport.mark.listincome.IncomeListController;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


public class FXMLDocumentController implements Initializable {
    
    @FXML
    private TextField id;
    @FXML
    private DatePicker date;
    @FXML
    private TextField category;
    @FXML
    private TextField amount;
    @FXML
    private Button saveButton;
    @FXML
    private Button cancelButton;
    @FXML
    private AnchorPane rootPane;
    
    private Boolean isInEditMode = Boolean.FALSE;
    
    dataBaseHandler databasehandler;
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        databasehandler = dataBaseHandler.getInstance();
        checkData();
    }    

    @FXML
    private void addIncome(ActionEvent event) {
        String incomeID = id.getText();
        String incomeDate = ((TextField)date.getEditor()).getText();
        String incomeCategory = category.getText();
        String incomeAmount = amount.getText();
        
        if(incomeID.isEmpty()||incomeDate.isEmpty()||incomeCategory.isEmpty()||incomeAmount.isEmpty()){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Please Enter in all feilds");
            alert.showAndWait();
            return;
        }
        
        if(isInEditMode){
            editIncome();
            return;
        }
         
        String qu = "INSERT INTO INCOME( id, date, category, amount ) VALUES ("
               + "'" + incomeID + "'," 
               + "'" + incomeDate + "',"
               + "'" + incomeCategory + "',"
               + "'" + incomeAmount + "'" 
               +")";

        System.out.println(qu);
        if(databasehandler.execAction(qu)){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText("Success");
            alert.showAndWait();
        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Error Occured");
            alert.showAndWait();
        }
    }

    @FXML
    private void cancel(ActionEvent event) {
        Stage stage = (Stage) rootPane.getScene().getWindow();
        stage.close();
    }

    private void checkData() {
        String qu = "SELECT category FROM INCOME";
        ResultSet rs = databasehandler.execQuery(qu);
        try {
            while(rs.next()){
                String categoryex = rs.getString("category");
                System.out.println(categoryex);
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void inflateUI(IncomeListController.Income income){
        
        id.setText(income.getId());
        date.setValue(LocalDate.parse(income.getDate()));
        category.setText(income.getCategory());
        amount.setText(income.getAmount());
        id.setEditable(false);
        isInEditMode = Boolean.TRUE;
        
    }

    private void editIncome() {
        IncomeListController.Income income = new IncomeListController.Income(id.getText(), ((TextField)date.getEditor()).getText(), category.getText(), amount.getText());
        if(databasehandler.updateIncome(income)){
            Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                alert1.setTitle("Success");
                alert1.setContentText("Income Updated.");
        }
        else{
             Alert alert2 = new Alert(Alert.AlertType.ERROR);
                    alert2.setTitle("Failed");
                    alert2.setHeaderText("could not be updated.");
        }
    }
    
}
