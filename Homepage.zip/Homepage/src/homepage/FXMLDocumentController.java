/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homepage;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDrawer;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 *
 * @author Chann
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private AnchorPane rootPane;
    @FXML
    private JFXDrawer drawer;
    @FXML
    private JFXButton drawerBtn;
    
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        VBox drawerPane;
        
        try {
            drawerPane = FXMLLoader.load(getClass().getResource("/homepage/drawerWindow.fxml"));
        
            drawer.setSidePane(drawerPane);
        
        }catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }    

    @FXML
    private void imageClicked(MouseEvent event) throws IOException {
        System.out.println("sdfkjsdhfksdhf");
        AnchorPane ap = FXMLLoader.load(getClass().getResource("loadThis.fxml"));
        rootPane.getChildren().setAll(ap);
    }

    @FXML
    private void drawDrawer(ActionEvent event) {
        initDrawer();
    }
    
    public void initDrawer() {
        if(drawer.isOpened()){
            drawer.close();
        }
        else{
            drawer.open();
        }
        
        
    }
    
    
    
   
    
}
