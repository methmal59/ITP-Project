/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homepage;

import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.transitions.hamburger.HamburgerSlideCloseTransition;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Chann
 */
public class DrawerWindowController implements Initializable {

    @FXML
    private JFXHamburger ham1;


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        hamClick();
        
    }    

    @FXML
    private void taskManagementBtnClicked(MouseEvent event) throws IOException {
        
        
        
    }
    
    private void hamClick(){
    
        HamburgerSlideCloseTransition animation1 = new HamburgerSlideCloseTransition(ham1);
            animation1.setRate(-1);
            ham1.addEventFilter(MouseEvent.MOUSE_CLICKED,(e)->{
                animation1.setRate(animation1.getRate()*-1);
                animation1.play();
                
                
                
            
                
        });
    }
    
    
}
