/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import database.DatabaseHandler;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author Chann
 */
public class TestDController implements Initializable {

    ObservableList<String> priorityComboOptions = FXCollections.observableArrayList("High","Medium","Low");
    ObservableList<String> sectionComboOptions = FXCollections.observableArrayList();
    ObservableList<String> labelComboOptions = FXCollections.observableArrayList();
    @FXML
    private JFXComboBox<String> priorityCombo;
    @FXML
    private JFXTextField taskName;
    @FXML
    private DatePicker dueDate;
    @FXML
    private JFXComboBox<String> sectionCombo;
    @FXML
    private JFXTextField description;
    @FXML
    private JFXComboBox<String> labelCombo;
    DatabaseHandler databaseHandler;
    @FXML
    private JFXButton taskSave;
    @FXML
    private JFXButton taskCancel;
    @FXML
    private JFXTextField taskId;
    
    Boolean isInEditMode = Boolean.FALSE;
    private static String sectionID;
    private static String labelID;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        databaseHandler = DatabaseHandler.getInstance();
        
        
        priorityCombo.setItems(priorityComboOptions);
        setSectionsCombo();
        setLabelCombo();
    }    

    private void setSectionsCombo() {
        String qu = "SELECT * FROM section";
        ResultSet rs = databaseHandler.execQuery(qu);
        try {
            while(rs.next()){
                String secName = rs.getString("sectionId");
                sectionComboOptions.add(secName);
                
                
            
            }
        } catch (Exception e) {
            
        }
        sectionCombo.setItems(sectionComboOptions);
    }
    
    private void setLabelCombo(){
        String qu = "SELECT * FROM label";
        ResultSet rs = databaseHandler.execQuery(qu);
        try {
            while(rs.next()){
                String lName = rs.getString("labelId");
                
                labelComboOptions.add(lName);
               
                
            
            }
        } catch (Exception e) {
            
        }
        labelCombo.setItems(labelComboOptions);
    
    }
    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {
        
        
        
        
        Parent addNewSectionUI = FXMLLoader.load(getClass().getResource("/section/addSection.fxml"));
        
       
        
        Stage addNewSectionStage = new Stage(StageStyle.UNIFIED);
        Scene addNewSectionScene = new Scene(addNewSectionUI);
        
        addNewSectionStage.setScene(addNewSectionScene);
        
        addNewSectionStage.show();
    }
    
    @FXML
    private void viewSecTable(ActionEvent event) throws IOException {
        Parent secTableUI = FXMLLoader.load(getClass().getResource("/section/sectionList.fxml"));
        
       
        
        Stage secTableStage = new Stage(StageStyle.UNIFIED);
        Scene secTableScene = new Scene(secTableUI);
        
        secTableStage.setScene(secTableScene);
        
        secTableStage.show();
    }
    
    @FXML
    private void viewLabelTable(ActionEvent event) throws IOException {
        Parent labelListUI = FXMLLoader.load(getClass().getResource("/label/labelList.fxml"));
        
       
        
        Stage labelListStage = new Stage(StageStyle.UNIFIED);
        Scene labelListScene = new Scene(labelListUI);
        
        labelListStage.setScene(labelListScene);
        
        labelListStage.show();
    }
    
     @FXML
    private void viewAddLabel(ActionEvent event) throws IOException {
        Parent addNewLabelUI = FXMLLoader.load(getClass().getResource("/label/addLabel.fxml"));
        
       
        
        Stage addNewLabelStage = new Stage(StageStyle.UNIFIED);
        Scene addNewLabelScene = new Scene(addNewLabelUI);
        
        addNewLabelStage.setScene(addNewLabelScene);
        
        addNewLabelStage.show();
    }

    @FXML
    private void taskSave(ActionEvent event) {
        String tid = taskId.getText();
        String priorityLevel = priorityCombo.getValue();
        String tName = taskName.getText();
        String dDate = dueDate.getEditor().getText();
        String section = sectionCombo.getValue();
        String tDescription = description.getText();
        String tLabel = labelCombo.getValue();
        
        if(tid.isEmpty()||priorityLevel.isEmpty()||tName.isEmpty()||dDate.isEmpty()||section.isEmpty()||tDescription.isEmpty()||tLabel.isEmpty()){
            System.out.println("one of the feild is empty!");
            return;
        }
        if(isInEditMode){
            editedInsertion();
            return;
        }
        
        /*stmt.execute("CREATE TABLE "+TABLE_NAME+"("
                        +"tid varchar(5) primary key,\n"
                        +"taskName varchar(1000),\n"
                        +"taskDue varchar(100),\n"
                        +"taskSectionId varchar(20),\n"
                        +"taskdescription varchar(10000),\n"
                        +"taskLabel varchar(100),\n"
                        +"FOREIGN KEY (taskLabelId) REFERENCES label(labelName)"
                        +"FOREIGN KEY (taskSectionId) REFERENCES section(sectionName)"
                        +")");*/
        
        /*String qu1 = "SELECT sectionId FROM section WHERE sectionName="+section;
        System.out.println(qu1);
        ResultSet rs1 = databaseHandler.execQuery(qu1);
        
        try {
            while(rs1.next()){
                sectionID = rs1.getString("sectionId");
                System.out.println(sectionID);
  
            }
        } catch (Exception e) {
            
        }
        
        String qu2 = "SELECT labelId FROM label WHERE labelName="+tLabel;
        System.out.println(qu2);
        ResultSet rs2 = databaseHandler.execQuery(qu2);
        try {
            while(rs2.next()){
                labelID = rs2.getString("labelId");
                System.out.println(labelID);
            }
        } catch (Exception e) {
            
        }*/
        
        
        String qu = "INSERT INTO task VALUES("+
                "'"+tid+"',"+
                "'"+priorityLevel+"',"+
                "'"+tName+"',"+
                "'"+dDate+"',"+
                "'"+section+"',"+
                "'"+tDescription+"',"+
                "'"+tLabel+"'"+
                ")";
        System.out.println(qu);
        if(databaseHandler.execAction(qu)){
            System.out.println("Success!");
        }else{
            System.out.println("Error");
        }
        
        
        
    }

    @FXML
    private void taskCancel(ActionEvent event) {
        
    	
        
    }

    private void editedInsertion() {
        
        TaskListController.task task = new TaskListController.task(taskId.getText(), taskName.getText(), priorityCombo.getValue(), dueDate.getEditor().getText(), sectionCombo.getValue(), description.getText());
        databaseHandler.updateLabel(task);
        
        if(databaseHandler.updateLabel(task)){
            System.out.println("Update Success!");
        }
        else{
            System.out.println("Fail update");
        }
        
        
        
    }
    
    public void passData(TaskListController.task task){
        taskId.setText(task.getTid());
        taskName.setText(task.getTname());
        priorityCombo.setValue(task.gettPriority());
        
        LocalDate l = myDate(task.getTdue());
        dueDate.setValue(l);
        
        sectionCombo.setValue(task.getTsec());
        description.setText(task.getTdescrip());
       
                
        taskId.setEditable(false);
        isInEditMode = Boolean.TRUE;
    }
    
    public static final LocalDate myDate(String dateString){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/mm/yyyy");
        LocalDate localDate1 = LocalDate.parse(dateString,formatter);
        return localDate1;
    }
    
}
