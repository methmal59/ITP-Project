/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDialog;
import com.jfoenix.controls.JFXDialogLayout;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.events.JFXDialogEvent;
import database.DatabaseHandler;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.effect.BoxBlur;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import static label.LabelListController.list2;
import taskmanagementfunction.FXMLDocumentController;

/**
 * FXML Controller class
 *
 * @author Chann
 */
public class AddTaskController implements Initializable {

    ObservableList<String> priorityComboOptions = FXCollections.observableArrayList("High","Medium","Low");
    ObservableList<String> sectionComboOptions = FXCollections.observableArrayList();
    
    @FXML
    private JFXComboBox<String> priorityCombo;
    @FXML
    private JFXTextField taskName;
    @FXML
    private DatePicker dueDate;
    @FXML
    private JFXComboBox<String> sectionCombo;
    @FXML
    private JFXTextField description;
    private JFXComboBox<String> labelCombo;
    DatabaseHandler databaseHandler;
    @FXML
    private JFXButton taskSave;
    @FXML
    private JFXButton taskCancel;
    @FXML
    private JFXTextField taskId;
    
    Boolean isInEditMode = Boolean.FALSE;
    private static String sectionID;
    private static String labelID;
    @FXML
    private Label priorityComboWarning;
    @FXML
    private Label taskNameWarning;
    @FXML
    private Label taskIdWarning;
    @FXML
    private Label dueDateWarning;
    @FXML
    private Label sectionWarning;
    @FXML
    private JFXButton addNewSection;
    @FXML
    private JFXButton editSection;
    @FXML
    private HBox labelHbox;
    @FXML
    private JFXButton selectLabels;
    @FXML
    private StackPane stackpane;
    @FXML
    private AnchorPane mainAnchor;
    
    public static String maxDate;
    public static String minDate;
    
   
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        databaseHandler = DatabaseHandler.getInstance();
        
        
        priorityCombo.setItems(priorityComboOptions);
        setSectionsCombo();
        
        
        
        priorityCombo.setValue("Medium");
    }    

    private void setSectionsCombo() {
        sectionComboOptions.clear();
        String qu = "SELECT * FROM section";
        ResultSet rs = databaseHandler.execQuery(qu);
        try {
            while(rs.next()){
                String secName = rs.getString("sectionName");
                sectionComboOptions.add(secName);
   
            }
        } catch (Exception e) {
            
        }
        sectionCombo.setItems(sectionComboOptions);
    }
    
    
    
    @FXML
    private void viewLabelTable(ActionEvent event) throws IOException {
        Parent labelListUI = FXMLLoader.load(getClass().getResource("/label/labelList.fxml"));
        
       
        
        Stage labelListStage = new Stage(StageStyle.UNIFIED);
        Scene labelListScene = new Scene(labelListUI);
        
        labelListStage.setScene(labelListScene);
        
        labelListStage.show();
        
        labelListStage.setOnCloseRequest((e)->{
                
            getSelectedLabelData();
            
        });
        
        
    }

    @FXML
    private void taskSave(ActionEvent event) throws SQLException {
        String tid = taskId.getText();
        String priorityLevel = priorityCombo.getValue();
        String tName = taskName.getText();
        String dDate = dueDate.getEditor().getText();

        String tDescription = description.getText();
       
        //getting Section **********************************************************************************
        String section = sectionCombo.getValue();
        String quSection = "SELECT * FROM section where sectionName LIKE '"+section+"'";
        ResultSet rsSection = databaseHandler.execQuery(quSection); 
        rsSection.next();
        String sectionReal = rsSection.getString("sectionId");

        if(tid.isEmpty()||priorityLevel.isEmpty()||tName.isEmpty()||dDate.isEmpty()||section.isEmpty()||tDescription.isEmpty()){
            
            loadDialogFailedEmpty();
            return;
        }
        if(isInEditMode){
            editedInsertion();
            return;
        }

        String qu = "INSERT INTO task VALUES("+
                "'"+tid+"',"+
                "'"+priorityLevel+"',"+
                "'"+tName+"',"+
                "'"+dDate+"',"+
                "'"+sectionReal+"',"+
                "'"+tDescription+"'"+
                
                ")";
        
        for(int i=0;i<list2.size() ;i++){
 
            Label labelName = (Label) labelHbox.getChildren().get(i);
            String labelText = labelName.getText();
            
            String labid = labelText;
            String ttid = tid;
            
            String qu3 = "SELECT labelColor FROM label where labelName LIKE '"+labid+"'";
            ResultSet rsColor = databaseHandler.execQuery(qu3); 
            rsColor.next();
            String lBackgroundColor = rsColor.getString("labelColor");
            System.out.println(lBackgroundColor);
                
            String qu2 = "INSERT INTO labelTask VALUES("+
                    "'"+ttid+"',"+
                    "'"+labid+"',"+
                    "'"+lBackgroundColor+"'"+
                    ")";
            
            System.out.println(ttid+labid);
            
            if(databaseHandler.execAction(qu2)){
                System.out.println("success");
                
            }else{
                System.out.println("failed");
                
                
            }
        }
        
        
        
        if(databaseHandler.execAction(qu)){
            loadDialogSuccess();
        }else{
            loadDialogFailed();
        }

    }

    @FXML
    private void taskCancel(ActionEvent event) {
        
    	
        
    }

    private void editedInsertion() {
        
        TaskListController.task task = new TaskListController.task(taskId.getText(), taskName.getText(), priorityCombo.getValue(), dueDate.getEditor().getText(), sectionCombo.getValue(), description.getText());
        databaseHandler.updateLabel(task);
        
        if(databaseHandler.updateLabel(task)){
           
            loadDialogUpdateSuccess();
        }
        else{
            
            loadDialogUpdateFailed();
        }
 
    }
    
    public void passData(TaskListController.task task){
        taskId.setText(task.getTid());
        taskName.setText(task.getTname());
        priorityCombo.setValue(task.gettPriority());
        
        LocalDate l = myDate(task.getTdue());
        dueDate.setValue(l);
        
        sectionCombo.setValue(task.getTsec());
        description.setText(task.getTdescrip());
        
                
        taskId.setEditable(false);
        isInEditMode = Boolean.TRUE;
    }
    
    public static final LocalDate myDate(String dateString){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/mm/yyyy");
        LocalDate localDate1 = LocalDate.parse(dateString,formatter);
        return localDate1;
    }

    @FXML
    private void PriorityLevelSelected(ActionEvent event) {
        String selectedLevel = priorityCombo.getValue();
        if(selectedLevel == "High"){
            priorityCombo.setStyle("-fx-background-color:#b91d47");
        }else if(selectedLevel == "Medium"){
            priorityCombo.setStyle("-fx-background-color:#1e7145");
        }else if(selectedLevel == "Low"){
            priorityCombo.setStyle("-fx-background-color:#ffc40d");
        }
    }

    @FXML
    private void showAddNewSection(ActionEvent event) throws IOException {
        
        Parent addNewSectionUI = FXMLLoader.load(getClass().getResource("/section/addSection.fxml"));
      
        Stage addNewSectionStage = new Stage(StageStyle.UNIFIED);
        Scene addNewSectionScene = new Scene(addNewSectionUI);
        
        addNewSectionStage.setScene(addNewSectionScene);
        
        addNewSectionStage.show();
        
        addNewSectionStage.setOnCloseRequest((e)->{
                
            setSectionsCombo();    
            priorityCombo.setItems(priorityComboOptions);
            
        });
   
    }
    
   

    @FXML
    private void showSectionTable(ActionEvent event) throws IOException {
        Parent secTableUI = FXMLLoader.load(getClass().getResource("/section/sectionList.fxml"));
  
        Stage secTableStage = new Stage(StageStyle.UNIFIED);
        Scene secTableScene = new Scene(secTableUI);
        
        secTableStage.setScene(secTableScene);
        
        secTableStage.show();
    }

    @FXML
    private void viewAddLabel(ActionEvent event) throws IOException {
        Parent addNewLabelUI = FXMLLoader.load(getClass().getResource("/label/addLabel.fxml"));
   
        Stage addNewLabelStage = new Stage(StageStyle.UNIFIED);
        Scene addNewLabelScene = new Scene(addNewLabelUI);
        
        addNewLabelStage.setScene(addNewLabelScene);
        
        addNewLabelStage.show();
    }
    
    
    public void getSelectedLabelData(){
        
        int size = list2.size();
        for(int i=0;i<size;i++){
            Label labelLabel = new Label((String) list2.get(i));
            labelLabel.getStyleClass().add("selectedLabels");
            String labelN = (String)list2.get(i);
            String qu = "SELECT * FROM label where labelName LIKE '"+labelN+"'";
            ResultSet rs = databaseHandler.execQuery(qu); 
            try {
                while(rs.next()){
                    String colorCode = rs.getString("labelColor");
                    labelLabel.setStyle("-fx-background-color:"+colorCode);
                    
                }
            } catch (SQLException ex) {
                Logger.getLogger(AddTaskController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            labelHbox.getChildren().add(labelLabel);
            labelHbox.setStyle("padding:5px;");
            System.out.println(labelLabel.getText());
        }
    }

    private void loadDialogSuccess() {
        
        BoxBlur blur = new BoxBlur(3,3,3);
        JFXDialogLayout content = new JFXDialogLayout();
        content.getStyleClass().add("JFXDialogLayout");
        content.setHeading(new Text("Inserted Successfully!"+"\n"));
        content.setBody(new Text("New task was created.\n"
        +"You can view any details about task by clicking the 'view Tasks' button"+"\n"));
        
        JFXDialog jd = new JFXDialog (stackpane,content,JFXDialog.DialogTransition.RIGHT);
        JFXButton button = new JFXButton("OK..Got it!");
        button.getStyleClass().add("okButton");
        button.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                jd.close();
                
            }
        
        });
        content.setActions(button);
        
        
        
        jd.setOnDialogClosed((JFXDialogEvent event1) -> {
            mainAnchor.setEffect(null);
        });
        mainAnchor.setEffect(blur);
        jd.show();
        
    }

    private void loadDialogFailed() {
        BoxBlur blur = new BoxBlur(3,3,3);
        JFXDialogLayout content = new JFXDialogLayout();
        content.getStyleClass().add("JFXDialogLayout");
        content.setHeading(new Text("Insertion Failed!"+"\n"));
        content.setBody(new Text("New task was not created.\n"
        +"Please carefully check the entered details and try again."+"\n"));
        
        JFXDialog jd = new JFXDialog (stackpane,content,JFXDialog.DialogTransition.RIGHT);
        JFXButton button = new JFXButton("OK..I'll Check!");
        button.getStyleClass().add("okButton");
        button.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                jd.close();
            }
        
        });
        content.setActions(button);
        
        jd.setOnDialogClosed((JFXDialogEvent event1) -> {
            mainAnchor.setEffect(null);
        
        });
        mainAnchor.setEffect(blur);
        
        jd.show();
    }

    private void loadDialogFailedEmpty() {
        BoxBlur blur = new BoxBlur(3,3,3);
        JFXDialogLayout content = new JFXDialogLayout();
        content.getStyleClass().add("JFXDialogLayout");
        content.setHeading(new Text("One of the fields are empty!"+"\n"));
        content.setBody(new Text("New task was not created.\n"
        +"Please check whether all fields are filled and try again."+"\n"));
        
        JFXDialog jd = new JFXDialog (stackpane,content,JFXDialog.DialogTransition.RIGHT);
        JFXButton button = new JFXButton("OK..I'll Check!");
        button.getStyleClass().add("okButton");
        button.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                jd.close();
            }
        
        });
        content.setActions(button);
        jd.setOnDialogClosed((JFXDialogEvent event1) -> {
            mainAnchor.setEffect(null);
        
        });
        mainAnchor.setEffect(blur);
        
        jd.show();    
    }

    private void loadDialogUpdateSuccess() {
        BoxBlur blur = new BoxBlur(3,3,3);
        JFXDialogLayout content = new JFXDialogLayout();
        content.getStyleClass().add("JFXDialogLayout");
        content.setHeading(new Text("Updated Successfully!"+"\n"));
        content.setBody(new Text("Task was updated successfully!\n"
        +"You can view updated details on the table."+"\n"));
        
        JFXDialog jd = new JFXDialog (stackpane,content,JFXDialog.DialogTransition.RIGHT);
        JFXButton button = new JFXButton("OK..Got it!");
        button.getStyleClass().add("okButton");
        button.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                jd.close();
            }
        
        });
        content.setActions(button);
     
        jd.setOnDialogClosed((JFXDialogEvent event1) -> {
            mainAnchor.setEffect(null);
        
        });
        mainAnchor.setEffect(blur);
        jd.show();
    }

    private void loadDialogUpdateFailed() {
        BoxBlur blur = new BoxBlur(3,3,3);
        JFXDialogLayout content = new JFXDialogLayout();
        content.getStyleClass().add("JFXDialogLayout");
        content.setHeading(new Text("Update Failed!"+"\n"));
        content.setBody(new Text("Task was not updated.\n"
        +"Please carefully check the entered details and try again."+"\n"));
        
        JFXDialog jd = new JFXDialog (stackpane,content,JFXDialog.DialogTransition.RIGHT);
        JFXButton button = new JFXButton("OK..I'll Check!");
        button.getStyleClass().add("okButton");
        button.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                jd.close();
            }
        
        });
        content.setActions(button);
        
        jd.setOnDialogClosed((JFXDialogEvent event1) -> {
            mainAnchor.setEffect(null);
        
        });
        mainAnchor.setEffect(blur);
        
        jd.show();
    }

    
}
