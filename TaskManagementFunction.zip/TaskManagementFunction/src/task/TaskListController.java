/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task;

import database.DatabaseHandler;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author Chann
 */
public class TaskListController implements Initializable {
    ObservableList<TaskListController.task> list = FXCollections.observableArrayList();
    @FXML
    private TableView<task> taskTable;
    @FXML
    private TableColumn<task, String> tid_col;
    @FXML
    private TableColumn<task, String> tname_col;
    @FXML
    private TableColumn<task, String> tpriority_col;
    @FXML
    private TableColumn<task, String> tdue_col;
    @FXML
    private TableColumn<task, String> tsection_col;
    @FXML
    private TableColumn<task, String> tdes_col;
    
    DatabaseHandler databaseHandler = DatabaseHandler.getInstance();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        loadData();
        initializeColumns();
        
        
    }    

    @FXML
    private void refreshTable(ActionEvent event) {
        loadData();
    }

    @FXML
    private void editTask(ActionEvent event) {
        TaskListController.task selectedTask = taskTable.getSelectionModel().getSelectedItem();
        
        if(selectedTask == null){
            System.out.println("selected Label is empty!");
            return;
        }
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/task/addTask.fxml"));
            Parent addNewTaskUI = loader.load();
            
            AddTaskController controller = loader.getController();
            controller.passData(selectedTask);

            Stage addNewTaskStage = new Stage(StageStyle.UNIFIED);
            Scene addNewTaskScene = new Scene(addNewTaskUI);
            addNewTaskStage.setScene(addNewTaskScene);
            addNewTaskStage.show();
            
            addNewTaskStage.setOnCloseRequest((e)->{
                
                refreshTable(new ActionEvent());
            
            });
            
            
        } catch (Exception e) {
        }
    }

    @FXML
    private void deleteTask(ActionEvent event) throws SQLException {
        
        TaskListController.task selectedTask = taskTable.getSelectionModel().getSelectedItem();
        
        if(selectedTask == null){
            System.out.println("selected Section is empty!");
            return;
        }
      
        boolean result = DatabaseHandler.getInstance().deleteTask(selectedTask);
        if(result){
            System.out.println("Deleted methods ran success!");
            list.remove(selectedTask);
        }else{
            System.out.println("deletion method run unsucess");
        }
        
    }

    private void initializeColumns() {
        tid_col.setCellValueFactory(new PropertyValueFactory<>("tid"));
        tname_col.setCellValueFactory(new PropertyValueFactory<>("tname"));
        tpriority_col.setCellValueFactory(new PropertyValueFactory<>("tPriority"));
        tdue_col.setCellValueFactory(new PropertyValueFactory<>("tdue"));
        tsection_col.setCellValueFactory(new PropertyValueFactory<>("tsec"));
        tdes_col.setCellValueFactory(new PropertyValueFactory<>("tdescrip"));
        
    }

    private void loadData() {
        
        list.clear();
    
        String qu = "SELECT * FROM task";
        ResultSet rs = databaseHandler.execQuery(qu);
        try {
            while(rs.next()){
                
                String tId = rs.getString("tid");                
                String tName = rs.getString("taskName");                
                String tPrior = rs.getString("tPriorityLevel");                
                String tDue = rs.getString("taskDue");                
                String tSec = rs.getString("sectionId");                
                String tDes = rs.getString("taskdescription");
                
                task t = new task(tId,tName,tPrior,tDue,tSec,tDes);
                list.add(t);
            
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        
        taskTable.setItems(list);
    }
    
    public static class task{
        public final SimpleStringProperty tid;
        public final SimpleStringProperty tname;
        public final SimpleStringProperty tPriority;
        public final SimpleStringProperty tdue;
        public final SimpleStringProperty tsec;
        public final SimpleStringProperty tdescrip;
        
        
        task(String tid,String tname,String tPriority,String tdue,String tsec,String tdescrip){
            this.tid = new SimpleStringProperty(tid);
            this.tname = new SimpleStringProperty(tname);
            this.tPriority = new SimpleStringProperty(tPriority);
            this.tdue = new SimpleStringProperty(tdue);
            this.tsec = new SimpleStringProperty(tsec);
            this.tdescrip = new SimpleStringProperty(tdescrip);
            
            
        }

        public String getTid() {
            return tid.get();
        }

        public String getTname() {
            return tname.get();
        }

        public String gettPriority() {
            return tPriority.get();
        }

        public String getTdue() {
            return tdue.get();
        }

        public String getTsec() {
            return tsec.get();
        }

        public String getTdescrip() {
            return tdescrip.get();
        }
        
    }
    
    
}
