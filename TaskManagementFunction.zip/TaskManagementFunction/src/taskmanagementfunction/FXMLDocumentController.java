/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taskmanagementfunction;


import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDrawer;
import com.jfoenix.controls.JFXListView;
import com.jfoenix.controls.JFXProgressBar;
import database.DatabaseHandler;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;


/**
 *
 * @author Chann
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    private JFXButton secTable;
    private JFXButton viewAddLabel;
    private JFXButton viewLabelTable;
    private JFXButton viewAddTask;
    @FXML
    private JFXDrawer drawer;
    private Button buttonAddSection;
    private JFXButton viewAttachment;
    private JFXListView<Label> taskList;
    DatabaseHandler databaseHandler;
    @FXML
    private VBox containerVbox;
    @FXML
    private JFXButton editTask;
    
    public static ObservableList<String> highList = FXCollections.observableArrayList();
    public static ObservableList<String> mediumList = FXCollections.observableArrayList();
    public static ObservableList<String> lowList = FXCollections.observableArrayList();
    @FXML
    private JFXProgressBar realProgressbar;
    @FXML
    private JFXProgressBar lowTaskProgress;
    @FXML
    private JFXProgressBar highTaskProgress;
    @FXML
    private JFXProgressBar mediumTaskProgress;
    
    private FXMLDocumentController fxmlDocumentController;
    @FXML
    private VBox calenderMainVbox;
    @FXML
    private Label TotalProgressLabel;
    @FXML
    private HBox week1Hbox;
    @FXML
    private HBox week2Hbox;
    @FXML
    private HBox week3Hbox;
    @FXML
    private HBox week4Hbox;
    @FXML
    private HBox week5Hbox;
    @FXML
    private VBox day1;
    @FXML
    private VBox day2;
    @FXML
    private VBox day3;
    @FXML
    private VBox day4;
    @FXML
    private VBox day5;
    @FXML
    private VBox day6;
    @FXML
    private VBox day7;
    @FXML
    private VBox day8;
    @FXML
    private VBox day9;
    @FXML
    private VBox day10;
    @FXML
    private VBox day11;
    @FXML
    private VBox day12;
    @FXML
    private VBox day13;
    @FXML
    private VBox day14;
    @FXML
    private VBox day15;
    @FXML
    private VBox day16;
    @FXML
    private VBox day17;
    @FXML
    private VBox day18;
    @FXML
    private VBox day19;
    @FXML
    private VBox day20;
    @FXML
    private VBox day21;
    @FXML
    private VBox day22;
    @FXML
    private VBox day23;
    @FXML
    private VBox day24;
    @FXML
    private VBox day25;
    @FXML
    private VBox day26;
    @FXML
    private VBox day27;
    @FXML
    private VBox day28;
    @FXML
    private VBox day29;
    @FXML
    private VBox day30;
    @FXML
    private VBox day31;
    @FXML
    private Label highProgressLabel;
    @FXML
    private Label mediumProgressLabel;
    @FXML
    private Label lowProgressLabel;
    @FXML
    private Label desRest;
    @FXML
    private Label desFull;
    @FXML
    private Label desHigh;
    @FXML
    private Label desMedium;
    @FXML
    private Label desLow;
    @FXML
    private Label calenderMonth;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        databaseHandler = DatabaseHandler.getInstance();
        
        VBox sidePane;
        try {
            sidePane = FXMLLoader.load(getClass().getResource("/task/addTask.fxml"));
            loadTaskList();
            drawer.setSidePane(sidePane);
            drawProgress();
            loadTaskToCalender();
           
            
        }catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }  
  
    public void loadPriorityLists() throws SQLException{
        String quCompletePriority = "select * from progressTable WHERE completedTaskPriority='Medium'";
        ResultSet rs = databaseHandler.execQuery(quCompletePriority);
        while(rs.next()){
            String mediumCompleted = rs.getString("tid");
            mediumList.add(mediumCompleted);
        }
        System.out.println(mediumList);
        
        String quCompletePriority2 = "select * from progressTable WHERE completedTaskPriority='High'";
        ResultSet rs2 = databaseHandler.execQuery(quCompletePriority2);
        while(rs2.next()){
            String highCompleted = rs2.getString("tid");
            highList.add(highCompleted);
        }
        System.out.println(highList);
        
        
        String quCompletePriority3 = "select * from progressTable WHERE completedTaskPriority='Low'";
        ResultSet rs3 = databaseHandler.execQuery(quCompletePriority3);
        while(rs3.next()){
            String lowCompleted = rs3.getString("tid");
            lowList.add(lowCompleted);
        }
        System.out.println(lowList);
    }
    
    
    public void loadTaskList() throws SQLException{
        containerVbox.getChildren().clear();
        loadPriorityLists();
    
        try {
            String qu = "SELECT * FROM section";
            System.out.println("select all fm section OK!");
            
            ResultSet rs = databaseHandler.execQuery(qu);
            
            while(rs.next()){ 
                String sId = rs.getString("sectionName");
                String secID = rs.getString("sectionId");
                      
                Label l = new Label(sId);
                l.getStyleClass().add("sectionLabel");
                HBox hb1 = new HBox();
                containerVbox.getChildren().add(hb1);
                hb1.getChildren().add(l);
               
                ListView lv = new ListView();
                lv.getStyleClass().add("lv");
               
                
                String qu1 = "select * from task WHERE sectionId='"+secID+"'";
                ResultSet rs2 = databaseHandler.execQuery(qu1);
                
                
                while(rs2.next()){
                    String tId = rs2.getString("tid");
                    String tName = rs2.getString("taskName");
  
                    HBox taskH = new HBox();
                    JFXButton taskCompleteBtn = new JFXButton("Done!");
                    taskCompleteBtn.setStyle("-fx-pref-width: 50px; -fx-text-fill:white; -fx-font-weight:bold; -fx-background-color:#00aba9; -fx-background-radius: 50px; -fx-border-radius: 50px;");
                    
                    taskCompleteBtn.setOnAction(new EventHandler<ActionEvent>(){
                
                    @Override public void handle(ActionEvent e){
                        //Make as Complete
                        String completedTaskId = tId;
                        lv.getItems().remove(tId);
                            
                        String quComplete = "select * from task WHERE tid='"+completedTaskId+"'";
                        ResultSet rs4 = databaseHandler.execQuery(quComplete);
                        try {
                            while(rs4.next()){
                                String priority = rs4.getString("tPriorityLevel");
                                System.out.println(priority);
                                if(priority.equals("Low")){
                                    
                                    try{
                                        String qu = "INSERT INTO progressTable VALUES("+
                                        "'"+completedTaskId+"',"+
                                        "'"+priority+"'"+
                                        ")";
                                        
                                        if(databaseHandler.execAction(qu)){
                                            System.out.println("Success!");
                                            
                                        }else{
                                            System.out.println("Error");
                                        }
                                        
                                    }catch (Exception e1){
                                        System.out.println(e1);
                                    }
                                    
                                    loadPriorityLists();
                                    
                                    
                                }
                                else if(priority.equals("Medium")){
                                    
                                    try{
                                        String qu2 = "INSERT INTO progressTable VALUES("+
                                        "'"+completedTaskId+"',"+
                                        "'"+priority+"'"+
                                        ")";
                                        
                                        if(databaseHandler.execAction(qu2)){
                                            System.out.println("Success!");
                                            
                                        }else{
                                            System.out.println("Error");
                                        }
                                    }catch (Exception e1){
                                        System.out.println(e1);
                                    }
                                    
                                    loadPriorityLists();
                                }
                                else if(priority.equals("High")){
                                    
                                    try{
                                        String qu3 = "INSERT INTO progressTable VALUES("+
                                        "'"+completedTaskId+"',"+
                                        "'"+priority+"'"+
                                        ")";
                                        
                                        if(databaseHandler.execAction(qu3)){
                                            System.out.println("Success!");
                                            
                                        }else{
                                            System.out.println("Error");
                                        }
                                    }catch (Exception e1){
                                        System.out.println(e1);
                                    }
                                    
                                    loadPriorityLists();
                                }
                            
                            }
                        } catch (SQLException ex) {
                            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        //Delete task from the task table
                        String getTask = "select * from task WHERE tid='"+tId+"'";
                        System.out.println(getTask);
                        ResultSet rsTask = databaseHandler.execQuery(getTask);
                        try {
                            rsTask.next();
                            String deleteTID = rsTask.getString("tid");
                            databaseHandler.deleteTask2(deleteTID);
                                
                        } catch (SQLException ex) {
                            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                            
                        try {
                            loadTaskList();
                        } catch (SQLException ex) {
                            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }});
    
                    taskH.getChildren().add(taskCompleteBtn);
                    
                    Label l1 = new Label(tName);
                    taskH.getChildren().add(l1);
         
                    String qu2 = "select * from labelTask WHERE tid='"+tId+"'";
                    ResultSet rs3 = databaseHandler.execQuery(qu2);
                    while(rs3.next()){
                        
                        String labels = rs3.getString("labelNamed");
                        String lBackgroundColor = rs3.getString("labelColor");
                        Label l2 = new Label(labels);
                        l2.setStyle("-fx-background-color:"+lBackgroundColor+"; -fx-padding: 5px; -fx-background-radius: 50px; -fx-border-radius:50px; -fx-font-weight:bold; -fx-text-fill: #ffffff;");
                        taskH.getChildren().add(l2); 
                        
                    }
                    
                    lv.getItems().add(taskH);
          
                }
                
                containerVbox.getChildren().add(lv);  
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void initDrawer() {
        if(drawer.isOpened()){
            drawer.close();
            try {
                loadTaskList();
            } catch (SQLException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        else{
            drawer.open();
        }
        
        
    }
    
    public void setFXMLDocumentController(FXMLDocumentController f){
        this.fxmlDocumentController = f;
    
    }

    

    @FXML
    private void viewTaskTable(ActionEvent event) throws IOException {
        Parent taskListUI = FXMLLoader.load(getClass().getResource("/task/taskList.fxml"));
        
       
        
        Stage taskListStage = new Stage(StageStyle.UNIFIED);
        Scene taskListScene = new Scene(taskListUI);
        
        taskListStage.setScene(taskListScene);
        
        taskListStage.show();
    }

    @FXML
    private void drawClick(ActionEvent event) {
        initDrawer();
    }

    private void drawProgress() throws SQLException {

            String qu3 = "select COUNT(*) from task WHERE tPriorityLevel='High'";
            ResultSet rs3 = databaseHandler.execQuery(qu3);
            rs3.next();
            double highListSize = highList.size();
            double totalHighCount = highListSize+Double.parseDouble(rs3.getString(1));
            double highProgress = (highListSize*100)/totalHighCount;
        
            String qu = "select COUNT(*) from task WHERE tPriorityLevel='Medium'";
            ResultSet rs = databaseHandler.execQuery(qu);
            rs.next();
            double mediumListSize = mediumList.size();
            double totalMediumCount = mediumListSize+Double.parseDouble(rs.getString(1));
            double mediumProgress = (mediumListSize*100)/totalMediumCount;
            
            String qu2 = "select COUNT(*) from task WHERE tPriorityLevel='Low'";
            ResultSet rs2 = databaseHandler.execQuery(qu2);
            rs2.next();
            double lowListSize = lowList.size();
            double totalLowCount = lowListSize+Double.parseDouble(rs2.getString(1));
            double lowProgress = (lowListSize*100)/totalLowCount;
            
            if(Math.ceil(highProgress)/100 == 0.0){
                highTaskProgress.setProgress(100);
                highProgressLabel.setText("100");
            }else{
                highTaskProgress.setProgress(Math.ceil(highProgress)/100);
                highProgressLabel.setText(Double.toString(Math.ceil(highProgress)));
            }
            
            
            
            if(Math.ceil(mediumProgress)/100 == 0.0){
                mediumTaskProgress.setProgress(100);
                mediumProgressLabel.setText("100");
            }else{
                mediumTaskProgress.setProgress(Math.ceil(mediumProgress)/100);
                mediumProgressLabel.setText(Double.toString(Math.ceil(mediumProgress)));
            }
            
            
            if(Math.ceil(lowProgress)/100 == 0.0){
                lowTaskProgress.setProgress(100);
                lowProgressLabel.setText("100");
            }else{
                lowTaskProgress.setProgress(Math.ceil(lowProgress)/100);
                lowProgressLabel.setText(Double.toString(Math.ceil(lowProgress)));
            }
            
            String qu4 = "select COUNT(*) from task";
            ResultSet rs4 = databaseHandler.execQuery(qu4);
            rs4.next();
            double totalTasks = Double.parseDouble(rs4.getString(1));
            
            
            double totalHighProgress = (50*highProgress)/100;
            if(totalHighProgress == 0.0){
                totalHighProgress = 50;
            }
            
            double totalMediumProgress = (30*mediumProgress)/100;
            if(totalMediumProgress == 0.0){
                totalMediumProgress = 30;
            }
            
            double totalLowProgress = (20*lowProgress)/100;
            if(totalLowProgress == 0.0){
                totalLowProgress = 20;
            }
            
            
            double fullProgress = Math.ceil(totalHighProgress+totalMediumProgress+totalLowProgress);
            
            if(fullProgress > 100){
                realProgressbar.setProgress(1);
            }else{
                realProgressbar.setProgress(fullProgress/100);
            }
            
            TotalProgressLabel.setText(Double.toString(fullProgress));
            
            desRest.setText(Double.toString(100-fullProgress)+"%");
            desFull.setText(Double.toString(fullProgress)+"%");
            desHigh.setText(Double.toString(Math.ceil(highProgress))+"%");
            desMedium.setText(Double.toString(Math.ceil(mediumProgress))+"%");
            desLow.setText(Double.toString(Math.ceil(lowProgress))+"%");
            
    }
    
    private void loadTaskToCalender() throws SQLException{
        String qu = "select * from task ";
        ResultSet rs = databaseHandler.execQuery(qu);
        while(rs.next()){
            String taskId = rs.getString("tid");
            String due = rs.getString("taskDue");
            
            char[] dCharArr = due.toCharArray();
            
            char m1 = dCharArr[0];
            char m2 = dCharArr[1];
            StringBuilder sb = new StringBuilder();
            sb.append(m1);
            sb.append(m2);
            String month = sb.toString();
            

            char d1 = dCharArr[3];
            char d2 = dCharArr[4];
            StringBuilder sb2 = new StringBuilder();
            sb2.append(d1);
            if(d2 != '/'){
                
                sb2.append(d2);
            } 
            String day = sb2.toString();
            
            
            String currentDate = java.time.LocalDate.now().toString();
      
            char[] dCurrentCharArr = currentDate.toCharArray();
            
            char currentm1 = dCurrentCharArr[5];
            char currentm2 = dCurrentCharArr[6];
            StringBuilder currentsb = new StringBuilder();
            currentsb.append(currentm1);
            currentsb.append(currentm2);
            String currentMonth = currentsb.toString();
            
            
            
            if(month.equals(currentMonth)){         
                int intDay = Integer.parseInt(day);
                Label l = new Label(taskId);
                l.getStyleClass().add("calenedrTask");
                if(intDay == 1){
                    day1.getChildren().add(l);
                }else if(intDay == 2){
                    day2.getChildren().add(l);
                }else if(intDay == 3){
                    day3.getChildren().add(l);
                }else if(intDay == 4){
                    day4.getChildren().add(l);
                }else if(intDay == 5){
                    day5.getChildren().add(l);
                }else if(intDay == 6){
                    day6.getChildren().add(l);
                }else if(intDay == 7){
                    day7.getChildren().add(l);
                }else if(intDay == 8){
                    day8.getChildren().add(l);
                }else if(intDay == 9){
                    day9.getChildren().add(l);
                }else if(intDay == 10){
                    day10.getChildren().add(l);
                }else if(intDay == 11){
                    day11.getChildren().add(l);
                }else if(intDay == 12){
                    day12.getChildren().add(l);
                }else if(intDay == 13){
                    day13.getChildren().add(l);
                }else if(intDay == 14){
                    day14.getChildren().add(l);
                }else if(intDay == 15){
                    day15.getChildren().add(l);
                }else if(intDay == 16){
                    day16.getChildren().add(l);
                }else if(intDay == 17){
                    day17.getChildren().add(l);
                }else if(intDay == 18){
                    day18.getChildren().add(l);
                }else if(intDay == 19){
                    day19.getChildren().add(l);
                }else if(intDay == 20){
                    day20.getChildren().add(l);
                }else if(intDay == 21){
                    day21.getChildren().add(l);
                }else if(intDay == 22){
                    day22.getChildren().add(l);
                }else if(intDay == 23){
                    day23.getChildren().add(l);
                }else if(intDay == 24){
                    day24.getChildren().add(l);
                }else if(intDay == 25){
                    day25.getChildren().add(l);
                }else if(intDay == 26){
                    day26.getChildren().add(l);
                }else if(intDay == 27){
                    day27.getChildren().add(l);
                }else if(intDay == 28){
                    day28.getChildren().add(l);
                }else if(intDay == 29){
                    day29.getChildren().add(l);
                }else if(intDay == 30){
                    day30.getChildren().add(l);
                }else if(intDay == 31){
                    day31.getChildren().add(l);
                }
                
            }
        }
       
        String currentDate = java.time.LocalDate.now().toString();
        char[] dCurrentCharArr = currentDate.toCharArray();
            
        char currentm1 = dCurrentCharArr[5];
        char currentm2 = dCurrentCharArr[6];
        
        StringBuilder currentsb = new StringBuilder();
        
        currentsb.append(currentm1);
        currentsb.append(currentm2);
        
        String currentMonth = currentsb.toString();
        if(currentMonth.equals("1")){
            calenderMonth.setText("January");
        }else if(currentMonth.equals("2")){
            calenderMonth.setText("February");
        }else if(currentMonth.equals("3")){
            calenderMonth.setText("March");
        }else if(currentMonth.equals("4")){
            calenderMonth.setText("April");
        }else if(currentMonth.equals("5")){
            calenderMonth.setText("May");
        }else if(currentMonth.equals("6")){
            calenderMonth.setText("June");
        }else if(currentMonth.equals("7")){
            calenderMonth.setText("July");
        }else if(currentMonth.equals("8")){
            calenderMonth.setText("August");
        }else if(currentMonth.equals("9")){
            calenderMonth.setText("September");
        }else if(currentMonth.equals("10")){
            calenderMonth.setText("Octomber");
        }else if(currentMonth.equals("11")){
            calenderMonth.setText("November");
        }else if(currentMonth.equals("12")){
            calenderMonth.setText("December");
        }
        
    
    }

    

    @FXML
    private void redrawProgress(ActionEvent event) throws SQLException {
        drawProgress();
    }
    
    
    
}
