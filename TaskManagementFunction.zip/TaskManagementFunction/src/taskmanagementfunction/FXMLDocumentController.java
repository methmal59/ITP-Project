/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taskmanagementfunction;


import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDrawer;
import com.jfoenix.controls.JFXListView;
import com.jfoenix.controls.JFXProgressBar;
import database.DatabaseHandler;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;


/**
 *
 * @author Chann
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private JFXButton secTable;
    @FXML
    private JFXButton viewAddLabel;
    @FXML
    private JFXButton viewLabelTable;
    @FXML
    private JFXButton viewAddTask;
    @FXML
    private JFXDrawer drawer;
    @FXML
    private Button buttonAddSection;
    @FXML
    private JFXButton viewTaskTable;
    @FXML
    private JFXButton viewAttachment;
    private JFXListView<Label> taskList;
    DatabaseHandler databaseHandler;
    @FXML
    private VBox containerVbox;
    @FXML
    private JFXButton editTask;
    
    public static ObservableList<String> highList = FXCollections.observableArrayList();
    public static ObservableList<String> mediumList = FXCollections.observableArrayList();
    public static ObservableList<String> lowList = FXCollections.observableArrayList();
    @FXML
    private JFXProgressBar realProgressbar;
    @FXML
    private JFXProgressBar expectedProfressbar;
    @FXML
    private JFXProgressBar lowTaskProgress;
    @FXML
    private JFXProgressBar highTaskProgress;
    @FXML
    private JFXProgressBar mediumTaskProgress;
    
    private FXMLDocumentController fxmlDocumentController;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        databaseHandler = DatabaseHandler.getInstance();
        
        viewAddTask.setVisible(false);
        buttonAddSection.setVisible(false);
        secTable.setVisible(false);
        viewAddLabel.setVisible(false);
        viewLabelTable.setVisible(false);
        //viewTaskTable.setVisible(false);
        viewAttachment.setVisible(false);
        
       
        VBox sidePane;
        try {
            sidePane = FXMLLoader.load(getClass().getResource("/task/addTask.fxml"));
            loadTaskList();
            drawer.setSidePane(sidePane);
           
            
        }catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }  
    
    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {
        
        
        
        
        Parent addNewSectionUI = FXMLLoader.load(getClass().getResource("/section/addSection.fxml"));
        
       
        
        Stage addNewSectionStage = new Stage(StageStyle.UNIFIED);
        Scene addNewSectionScene = new Scene(addNewSectionUI);
        
        addNewSectionStage.setScene(addNewSectionScene);
        
        addNewSectionStage.show();
    }
    public void loadPriorityLists() throws SQLException{
        String quCompletePriority = "select * from progressTable WHERE completedTaskPriority='Medium'";
        ResultSet rs = databaseHandler.execQuery(quCompletePriority);
        while(rs.next()){
            String mediumCompleted = rs.getString("tid");
            mediumList.add(mediumCompleted);
        }
        System.out.println(mediumList);
        
        String quCompletePriority2 = "select * from progressTable WHERE completedTaskPriority='High'";
        ResultSet rs2 = databaseHandler.execQuery(quCompletePriority2);
        while(rs2.next()){
            String highCompleted = rs2.getString("tid");
            highList.add(highCompleted);
        }
        System.out.println(highList);
        
        
        String quCompletePriority3 = "select * from progressTable WHERE completedTaskPriority='Low'";
        ResultSet rs3 = databaseHandler.execQuery(quCompletePriority3);
        while(rs3.next()){
            String lowCompleted = rs3.getString("tid");
            lowList.add(lowCompleted);
        }
        System.out.println(lowList);
        
        //finally call here progresss drawing thing
        //drawProgress();
        
        
    }
    
    public void loadTaskList() throws SQLException{
        containerVbox.getChildren().clear();
        loadPriorityLists(); // not implemented yet
    
        try {
            String qu = "SELECT * FROM section";
            System.out.println("select all fm section OK!");
            
            ResultSet rs = databaseHandler.execQuery(qu);
            
            while(rs.next()){
                
                String sId = rs.getString("sectionName");
                String secID = rs.getString("sectionId");
                
                
                Label l = new Label(sId);
                l.getStyleClass().add("sectionLabel");
                HBox hb1 = new HBox();
                containerVbox.getChildren().add(hb1);
                hb1.getChildren().add(l);
               
                ListView lv = new ListView();
                lv.getStyleClass().add("lv");
               
                
                String qu1 = "select * from task WHERE sectionId='"+secID+"'";
                ResultSet rs2 = databaseHandler.execQuery(qu1);
                
                
                while(rs2.next()){
                   String tId = rs2.getString("tid");
                    String tName = rs2.getString("taskName");
//                    String due = rs2.getString("taskDueDate");
//                    String prior =  rs2.getString("taskPriority");
//                    String secId = rs2.getString("sectionID");
//                    String des = rs2.getString("taskDescription");
                    
                    
                    HBox taskH = new HBox();
                    JFXButton taskCompleteBtn = new JFXButton("Done!");
                    taskCompleteBtn.setStyle("-fx-pref-width: 50px; -fx-text-fill:white; -fx-font-weight:bold; -fx-background-color:#00aba9; -fx-background-radius: 50px; -fx-border-radius: 50px;");
                    
                    taskCompleteBtn.setOnAction(new EventHandler<ActionEvent>(){
                
                    @Override public void handle(ActionEvent e){
                
                        
                            //Mark as complete
                            String completedTaskId = tId;
                            lv.getItems().remove(tId);
                            
                            String quComplete = "select * from task WHERE tid='"+completedTaskId+"'";
                            ResultSet rs4 = databaseHandler.execQuery(quComplete);
                            try {
                            while(rs4.next()){
                                String priority = rs4.getString("tPriorityLevel");
                                System.out.println(priority);
                                if(priority.equals("Low")){
                                    
                                    try{
                                        String qu = "INSERT INTO progressTable VALUES("+
                                        "'"+completedTaskId+"',"+
                                        "'"+priority+"'"+
                                        ")";
                                        if(databaseHandler.execAction(qu)){
                                            System.out.println("Success!");
                                            
                                        }else{
                                            System.out.println("Error");
                                        }
                                    }catch (Exception e1){
                                        System.out.println(e1);
                                    }
                                    
                                    loadPriorityLists();
                                    
                                    
                                }
                                else if(priority.equals("Medium")){
                                    
                                    try{
                                        String qu2 = "INSERT INTO progressTable VALUES("+
                                        "'"+completedTaskId+"',"+
                                        "'"+priority+"'"+
                                        ")";
                                        
                                        if(databaseHandler.execAction(qu2)){
                                            System.out.println("Success!");
                                            
                                        }else{
                                            System.out.println("Error");
                                        }
                                    }catch (Exception e1){
                                        System.out.println(e1);
                                    }
                                    
                                    loadPriorityLists();
                                }
                                else if(priority.equals("High")){
                                    
                                    try{
                                        String qu3 = "INSERT INTO progressTable VALUES("+
                                        "'"+completedTaskId+"',"+
                                        "'"+priority+"'"+
                                        ")";
                                        
                                        if(databaseHandler.execAction(qu3)){
                                            System.out.println("Success!");
                                            
                                        }else{
                                            System.out.println("Error");
                                        }
                                    }catch (Exception e1){
                                        System.out.println(e1);
                                    }
                                    
                                    loadPriorityLists();
                                }
                                
                                //System.out.println(mediumList);
                                //System.out.println(completedTaskId);
                            
                            }
                        } catch (SQLException ex) {
                            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                            
                            
                            //Delete task from the task table
                            String getTask = "select * from task WHERE tid='"+tId+"'";
                            System.out.println(getTask);
                            ResultSet rsTask = databaseHandler.execQuery(getTask);
                            try {
                                rsTask.next();
                                String deleteTID = rsTask.getString("tid");
                                databaseHandler.deleteTask2(deleteTID);
                                
                            } catch (SQLException ex) {
                                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            
                            //Nicely working but task is not removed until it is deleted from the database
                            try {
                                loadTaskList();
                            } catch (SQLException ex) {
                                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            
                            
                            
                            
     
                            
                            
                        
                        System.out.println(completedTaskId);
                        

                        }
                    });
                    taskH.getChildren().add(taskCompleteBtn);
                    
                    Label l1 = new Label(tName);
                    taskH.getChildren().add(l1);
                    //lv.getItems().add(l1);
                    
                    String qu2 = "select * from labelTask WHERE tid='"+tId+"'";
                    ResultSet rs3 = databaseHandler.execQuery(qu2);
                    while(rs3.next()){
                        
                        String labels = rs3.getString("labelNamed");
                        Label l2 = new Label(labels);
                        System.out.println(labels);
                        //getting label color
                        /*String quForGettingLabelColor = "SELECT * FROM label where labelName LIKE '"+labels+"'";
                        ResultSet rsOfGettingLabelColor = databaseHandler.execQuery(quForGettingLabelColor);
                        
                        System.out.println(quForGettingLabelColor);
                        try {
                            while(rs.next()){
                               //String colorCode = rs.getString("labelColor");
                                System.out.println(rsOfGettingLabelColor.getString("labelColor"));
                                //l2.setStyle("-fx-background-color:"+colorCode);
                    
                            }
                        } catch (SQLException ex) {
                            Logger.getLogger(AddTaskController.class.getName()).log(Level.SEVERE, null, ex);
                        }*/
                        
                        
                        
                        taskH.getChildren().add(l2);
                        //lv.getItems().add(l2);
                        
                        
                       
                    }
                    
                     lv.getItems().add(taskH);
                     
                
                }
                
                containerVbox.getChildren().add(lv);
                
                
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
    }
    
    
    
    
    
    public void initDrawer() {
        if(drawer.isOpened()){
            drawer.close();
            try {
                loadTaskList();
            } catch (SQLException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        else{
            drawer.open();
        }
        
        
    }
    
    public void setFXMLDocumentController(FXMLDocumentController f){
        this.fxmlDocumentController = f;
    
    }
    
    

    @FXML
    private void viewSecTable(ActionEvent event) throws IOException {
        Parent secTableUI = FXMLLoader.load(getClass().getResource("/section/sectionList.fxml"));
        
       
        
        Stage secTableStage = new Stage(StageStyle.UNIFIED);
        Scene secTableScene = new Scene(secTableUI);
        
        secTableStage.setScene(secTableScene);
        
        secTableStage.show();
    }

    @FXML
    private void viewAddLabel(ActionEvent event) throws IOException {
        Parent addNewLabelUI = FXMLLoader.load(getClass().getResource("/label/addLabel.fxml"));
        
       
        
        Stage addNewLabelStage = new Stage(StageStyle.UNIFIED);
        Scene addNewLabelScene = new Scene(addNewLabelUI);
        
        addNewLabelStage.setScene(addNewLabelScene);
        
        addNewLabelStage.show();
    }

    @FXML
    private void viewLabelTable(ActionEvent event) throws IOException {
        Parent labelListUI = FXMLLoader.load(getClass().getResource("/label/labelList.fxml"));
        
       
        
        Stage labelListStage = new Stage(StageStyle.UNIFIED);
        Scene labelListScene = new Scene(labelListUI);
        
        labelListStage.setScene(labelListScene);
        
        labelListStage.show();
        
        
        
    }

    @FXML
    private void viewAddTask(ActionEvent event) throws IOException {
        Parent addNewTaskUI = FXMLLoader.load(getClass().getResource("/task/addTask.fxml"));
        
       
        
        Stage addNewTaskStage = new Stage(StageStyle.UNIFIED);
        Scene addNewTaskScene = new Scene(addNewTaskUI);
        
        addNewTaskStage.setScene(addNewTaskScene);
        
        addNewTaskStage.show();
    }

    @FXML
    private void viewTaskTable(ActionEvent event) throws IOException {
        Parent taskListUI = FXMLLoader.load(getClass().getResource("/task/taskList.fxml"));
        
       
        
        Stage taskListStage = new Stage(StageStyle.UNIFIED);
        Scene taskListScene = new Scene(taskListUI);
        
        taskListStage.setScene(taskListScene);
        
        taskListStage.show();
    }

    @FXML
    private void viewAttachment(ActionEvent event) throws IOException {
        Parent addAttachmentUI = FXMLLoader.load(getClass().getResource("/attachment/addAttachment.fxml"));
        
       
        
        Stage addAttachmentStage = new Stage(StageStyle.UNIFIED);
        Scene addAttachmentScene = new Scene(addAttachmentUI);
        
        addAttachmentStage.setScene(addAttachmentScene);
        
        addAttachmentStage.show();
    }

    @FXML
    private void drawClick(ActionEvent event) {
        initDrawer();
    }

    @FXML
    private void drawProgress(ActionEvent event) throws SQLException {
            
        
            String qu3 = "select COUNT(*) from task WHERE tPriorityLevel='High'";
            ResultSet rs3 = databaseHandler.execQuery(qu3);
            rs3.next();
            double highListSize = highList.size();
            double totalHighCount = highListSize+Double.parseDouble(rs3.getString(1));
            double highProgress = (highListSize*100)/totalHighCount;
        
            String qu = "select COUNT(*) from task WHERE tPriorityLevel='Medium'";
            ResultSet rs = databaseHandler.execQuery(qu);
            rs.next();
            double mediumListSize = mediumList.size();
            double totalMediumCount = mediumListSize+Double.parseDouble(rs.getString(1));
            double mediumProgress = (mediumListSize*100)/totalMediumCount;

            String qu2 = "select COUNT(*) from task WHERE tPriorityLevel='Low'";
            ResultSet rs2 = databaseHandler.execQuery(qu2);
            rs2.next();
            double lowListSize = lowList.size();
            double totalLowCount = lowListSize+Double.parseDouble(rs2.getString(1));
            double lowProgress = (lowListSize*100)/totalLowCount;
            
            
           
            highTaskProgress.setProgress(highProgress/100);
            //highTaskProgress.setStyle("-fx-accent: yellow;");
            mediumTaskProgress.setProgress(mediumProgress/100);
            lowTaskProgress.setProgress(lowProgress/100);
            
            System.out.println(highProgress+" "+mediumProgress+" "+lowProgress);
            
            String qu4 = "select COUNT(*) from task";
            ResultSet rs4 = databaseHandler.execQuery(qu4);
            rs4.next();
            double totalTasks = Double.parseDouble(rs4.getString(1));
            
            
            
            
            double totalHighCompletion = (highProgress*50)/100;
            System.out.println(totalHighCompletion);
            
            double totalMediumCompletion = (mediumProgress*30)/100;
            System.out.println(totalMediumCompletion);
            
            double totalLowCompletion = (lowProgress*20)/100;
            System.out.println(totalLowCompletion);
            
            double totalCompletion = (totalHighCompletion*0.5)+(totalMediumCompletion*0.3)+(totalLowCompletion *0.2);
            System.out.println(totalCompletion);
            
            
            
    }
    
    
    
}
