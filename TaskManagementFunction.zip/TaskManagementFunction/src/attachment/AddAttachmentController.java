/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package attachment;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import database.DatabaseHandler;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.Blob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

/**
 * FXML Controller class
 *
 * @author Chann
 */
public class AddAttachmentController implements Initializable {

    @FXML
    private JFXComboBox<String> tidCombo;
    @FXML
    private ImageView attImage;
    @FXML
    private ImageView attImage2;
    @FXML
    private ImageView attImage3;
    @FXML
    private ImageView attImage4;
    @FXML
    private ImageView attImage5;
    @FXML
    private JFXButton saveAttchment;
    
    @FXML
    private JFXTextField attchmentText;
    
    DatabaseHandler databaseHandler;
    ObservableList<String> tidComboOptions = FXCollections.observableArrayList();
    int count;
    String[] strArray = new String[5];
    @FXML
    private JFXTextField attachmentId;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        databaseHandler = DatabaseHandler.getInstance();
        
        setTidCombo();
    }    

    @FXML
    private void saveAttchment(ActionEvent event) throws FileNotFoundException, SQLException, IOException {
    /*
        for(int j=0;j<=5;j++){
            String attId = attachmentId.getText();
            
            File file = new File(strArray[j]);
            FileInputStream input = new FileInputStream(file);
            
            String iName = file.getName();
            Blob image = (Blob) databaseHandler.createBlob(iName);
            
            String tid = tidCombo.getValue();
            
            if(tid.isEmpty()||attId.isEmpty()||tid.isEmpty()){
                System.out.println("one of the feild is empty!");
                return;
            }
            
            String qu = "INSERT INTO attachment VALUES("+
                "'"+attId+"',"+
                "'"+iName+"',"+
                "'"+image+"',"+
                "'"+tid+"'"+
                ")";
            System.out.println(qu);
            if(databaseHandler.execAction(qu)){
                System.out.println("Success!");
            }else{
                System.out.println("Error");
            }
            
        }
        
        
        
        
        
        if(isInEditMode){
            editedInsertion();
            return;
        }
        */
      
        
        
        
       
        
    }

    @FXML
    private void browseImage(ActionEvent event) {
         FileChooser browse = new FileChooser();
        File f = browse.showOpenDialog(null);
     
        String fileName = f.getAbsolutePath();
        
        
        attchmentText.setText(fileName);  
        
        File f1= new File(attchmentText.getText());
        Image attThumbImage = new Image(f1.toURI().toString());
        
        if(count == 0){
            attImage.setImage(attThumbImage);
            count = count+1;
            String path = f1.getAbsolutePath();
            strArray[0] = path;
        }
        else if(count == 1){
            attImage2.setImage(attThumbImage);
            count = count+1;
            String path2 = f1.getAbsolutePath();
            strArray[1] = path2;
           
        }
        else if(count == 2){
            attImage3.setImage(attThumbImage);
            count = count+1;
            String path3 = f1.getAbsolutePath();
            strArray[2] = path3;
           
        }
        else if(count == 3){
            attImage4.setImage(attThumbImage);
            count = count+1;
            String path4 = f1.getAbsolutePath();
            strArray[3] = path4;
           
        }
        else if(count == 4){
            attImage5.setImage(attThumbImage);
            count = count+1;
            String path5 = f1.getAbsolutePath();
            strArray[4] = path5;
           
        }
    }

    private void setTidCombo() {
        String qu = "SELECT * FROM task";
        ResultSet rs = databaseHandler.execQuery(qu);
        try {
            while(rs.next()){
                String taskId = rs.getString("tid"); 
                tidComboOptions.add(taskId);
 
            }
        } catch (Exception e) {
            
        }
        
        
        tidCombo.setItems(tidComboOptions);
    }
    
}
