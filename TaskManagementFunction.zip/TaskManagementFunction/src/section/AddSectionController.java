/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package section;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDialog;
import com.jfoenix.controls.JFXDialogLayout;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.events.JFXDialogEvent;
import database.DatabaseHandler;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.effect.BoxBlur;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 * @author Chann
 */
public class AddSectionController implements Initializable {

    @FXML
    private JFXButton addSectionBtn;
    DatabaseHandler databaseHandler;
    @FXML
    private JFXTextField sectionName;
    @FXML
    private JFXTextField sectionID;

    private Boolean isInEditMode = Boolean.FALSE; 
    @FXML
    private AnchorPane addSectionRootAnchor;
    private StackPane addSectionStackpane;
    @FXML
    private StackPane sectionStackPane;
    @FXML
    private JFXButton sectionCancel;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        databaseHandler = DatabaseHandler.getInstance();
    }    

    @FXML
    private void addSection(ActionEvent event) {
        
        String sectionId = sectionID.getText();
        String sectionNameText = sectionName.getText();
        
        if(sectionId.isEmpty()||sectionNameText.isEmpty()){
            loadDialogFailedEmpty();
            return;
        }
        if(isInEditMode){
            editedInsertion();
            return;
        }
        
        String qu = "INSERT INTO section VALUES("+
                "'"+sectionId+"',"+
                "'"+sectionNameText+"'"+
                ")";
       
        if(databaseHandler.execAction(qu)){
            loadDialogSuccess();
            
        }else{
            loadDialogFailed();
        }
        
    }
    
    
    private void checkData(){
        String qu = "SELECT * FROM section";
        ResultSet rs = databaseHandler.execQuery(qu);
        try {
            while(rs.next()){
                String secName = rs.getString("sectionName");
            }
        } catch (Exception e) {
            
        }
    }
    
    public void passData(SectionListController.section section){
        sectionID.setText(section.getId());
        sectionName.setText(section.getName());
        sectionID.setEditable(false);
        isInEditMode = Boolean.TRUE;
    }

    private void editedInsertion() {
        SectionListController.section section = new SectionListController.section(sectionID.getText(), sectionName.getText());
        databaseHandler.updateSection(section);
        
        if(databaseHandler.updateSection(section)){
            loadDialogUpdateSuccess();
        }
        else{
            loadDialogUpdateFailed();
        }
        
    }
    
    private void loadDialogSuccess() {
        
        BoxBlur blur = new BoxBlur(3,3,3);
        JFXDialogLayout content = new JFXDialogLayout();
        content.getStyleClass().add("JFXDialogLayout");
        content.setHeading(new Text("Section Created Successfully!"+"\n"));
        content.setBody(new Text("New section was created.\n"
        +"You can view any details about sections by clicking the 'Edit Section' button"+"\n"));
        
        JFXDialog jd = new JFXDialog (sectionStackPane,content,JFXDialog.DialogTransition.TOP);
        JFXButton button = new JFXButton("OK..Got it!");
        button.getStyleClass().add("okButton");
        button.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                jd.close();
                
            }
        
        });
        content.setActions(button);
        
        
        
        jd.setOnDialogClosed((JFXDialogEvent event1) -> {
            addSectionRootAnchor.setEffect(null);
        
        });
        addSectionRootAnchor.setEffect(blur);
        jd.show();
        
    }
    
    private void loadDialogFailed() {
        
        BoxBlur blur = new BoxBlur(3,3,3);
        JFXDialogLayout content = new JFXDialogLayout();
        content.getStyleClass().add("JFXDialogLayout");
        content.setHeading(new Text("Section Creation Failed!"+"\n"));
        content.setBody(new Text("New section was not created!\n"
        +"Please carefully check the entered details and try again."+"\n"));
        
        JFXDialog jd = new JFXDialog (sectionStackPane,content,JFXDialog.DialogTransition.TOP);
        JFXButton button = new JFXButton("OK..I'll Check!");
        button.getStyleClass().add("okButton");
        button.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                jd.close();
            }
        
        });
        content.setActions(button);

        jd.setOnDialogClosed((JFXDialogEvent event1) -> {
            addSectionRootAnchor.setEffect(null);
        
        });
        addSectionRootAnchor.setEffect(blur);
        jd.show();
        
    }
    private void loadDialogFailedEmpty() {
        BoxBlur blur = new BoxBlur(3,3,3);
        JFXDialogLayout content = new JFXDialogLayout();
        content.getStyleClass().add("JFXDialogLayout");
        content.setHeading(new Text("One of the fields are empty!"+"\n"));
        content.setBody(new Text("New Section was not created.\n"
        +"Please check whether all fields are filled and try again."+"\n"));
        
        JFXDialog jd = new JFXDialog (sectionStackPane,content,JFXDialog.DialogTransition.TOP);
        JFXButton button = new JFXButton("OK..I'll Check!");
        button.getStyleClass().add("okButton");
        button.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                jd.close();
            }
        
        });
        content.setActions(button);
        jd.setOnDialogClosed((JFXDialogEvent event1) -> {
            addSectionRootAnchor.setEffect(null);
        
        });
        addSectionRootAnchor.setEffect(blur);
        
        jd.show();    
    }

    @FXML
    private void sectionCancelAction(ActionEvent event) {
       

    }

    private void loadDialogUpdateSuccess() {
        BoxBlur blur = new BoxBlur(3,3,3);
        JFXDialogLayout content = new JFXDialogLayout();
        content.getStyleClass().add("JFXDialogLayout");
        content.setHeading(new Text("Section was updated successfully!"+"\n"));
        content.setBody(new Text("Section was updated.\n"
        +"You can view updated details on the table."+"\n"));
        
        JFXDialog jd = new JFXDialog (sectionStackPane,content,JFXDialog.DialogTransition.TOP);
        JFXButton button = new JFXButton("OK..Got it!");
        button.getStyleClass().add("okButton");
        button.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                jd.close();
            }
        
        });
        content.setActions(button);
        
        
        
        jd.setOnDialogClosed((JFXDialogEvent event1) -> {
            addSectionRootAnchor.setEffect(null);
        
        });
        addSectionRootAnchor.setEffect(blur);
        jd.show();
    }

    private void loadDialogUpdateFailed() {
        BoxBlur blur = new BoxBlur(3,3,3);
        JFXDialogLayout content = new JFXDialogLayout();
        content.getStyleClass().add("JFXDialogLayout");
        content.setHeading(new Text("Section Update Failed!"+"\n"));
        content.setBody(new Text("Section was not updated!\n"
        +"Please carefully check the entered details and try again."+"\n"));
        
        JFXDialog jd = new JFXDialog (sectionStackPane,content,JFXDialog.DialogTransition.TOP);
        JFXButton button = new JFXButton("OK..I'll Check!");
        button.getStyleClass().add("okButton");
        button.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                jd.close();
            }
        
        });
        content.setActions(button);
        
        
        
        jd.setOnDialogClosed((JFXDialogEvent event1) -> {
            addSectionRootAnchor.setEffect(null);
        
        });
        addSectionRootAnchor.setEffect(blur);
        jd.show();
    }
    
}
