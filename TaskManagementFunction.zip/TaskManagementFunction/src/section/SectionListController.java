/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package section;

import database.DatabaseHandler;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author Chann
 */
public class SectionListController implements Initializable {
    ObservableList<section> list = FXCollections.observableArrayList();

    @FXML
    private AnchorPane sec_root_pane;
    @FXML
    private TableView<section> sec_table_view;
    @FXML
    private TableColumn<section, String> sec_id_col;
    @FXML
    private TableColumn<section, String> sec_name_col;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        initializeColumns();
        
        loadData();
        
    }    

    private void initializeColumns() {
        
        sec_id_col.setCellValueFactory(new PropertyValueFactory<>("id"));
        sec_name_col.setCellValueFactory(new PropertyValueFactory<>("name"));
        
    }

    private void loadData() {
        list.clear();
        DatabaseHandler databaseHandler = DatabaseHandler.getInstance();
        
        String qu = "SELECT * FROM section";
        ResultSet rs = databaseHandler.execQuery(qu);
        try {
            while(rs.next()){
                String secId = rs.getString("sectionId");
                String secName = rs.getString("sectionName");
                System.out.println(secName+secId);
                
                section n = new section(secId,secName);
                list.add(n);
            
            }
        } catch (Exception e) {
            
        }
        
        sec_table_view.setItems(list);
    }

    @FXML
    private void deleteSelectedSection(ActionEvent event) throws SQLException {
        section selectedSection = sec_table_view.getSelectionModel().getSelectedItem();
        
        if(selectedSection == null){
            System.out.println("selected Section is empty!");
            return;
        }
        boolean result = DatabaseHandler.getInstance().deleteSection(selectedSection);
        if(result){
            System.out.println("Deleted methods ran success!");
            list.remove(selectedSection);
        }else{
            System.out.println("deletion method run unsucess");
        }
        
    }

    @FXML
    private void removeSelectedSection(ActionEvent event) {
        
        section selectedSection = sec_table_view.getSelectionModel().getSelectedItem();
        
        if(selectedSection == null){
            System.out.println("selected Section is empty!");
            return;
        }
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/section/addSection.fxml"));
            Parent addNewSectionUI = loader.load();
            
            AddSectionController controller = loader.getController();
            controller.passData(selectedSection);
       
        
            Stage addNewSectionStage = new Stage(StageStyle.UNIFIED);
            Scene addNewSectionScene = new Scene(addNewSectionUI);
            addNewSectionStage.setScene(addNewSectionScene);
            addNewSectionStage.show();
            
            addNewSectionStage.setOnCloseRequest((e)->{
                
                refreshTable(new ActionEvent());
            
            });
            
            
        } catch (Exception e) {
        }
        
        
        
    }

    @FXML
    private void refreshTable(ActionEvent event) {
        loadData();
        
    }
    
    public static class section{
        private final SimpleStringProperty id;
        private final SimpleStringProperty name;
        
        section(String id,String name){
            this.id = new SimpleStringProperty(id);
            this.name = new SimpleStringProperty(name);
        }

        public String getId() {
            return id.get();
        }

        public String getName() {
            return name.get();
        }
        
        
    }
    
}
