/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Alert;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDialog;
import com.jfoenix.controls.JFXDialogLayout;
import com.jfoenix.controls.events.JFXDialogEvent;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.effect.BoxBlur;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;

/**
 *
 * @author Chann
 */
public class alertMaker {
    
    
    public static void showStylishDialog(StackPane root,Node blurNode){
        BoxBlur blur = new BoxBlur(3,3,3);
        
        JFXDialogLayout dialogLayout = new JFXDialogLayout();
        JFXButton button = new JFXButton("OK");
        button.getStyleClass().add("dialogButton");
        
        JFXDialog dialog = new JFXDialog(root,dialogLayout,JFXDialog.DialogTransition.TOP);
        
        button.addEventHandler(MouseEvent.MOUSE_CLICKED,(MouseEvent mouseEvent)->{
            dialog.close();
        });
        
        Label dialogTitle = new Label("Successfully added to database");
        dialogLayout.setHeading(dialogTitle);
        dialogLayout.setActions(button);
        dialog.show();
        
        dialog.setOnDialogClosed((JFXDialogEvent event1) -> {
            blurNode.setEffect(null);
        
        });
        
        blurNode.setEffect(blur);
    
    }
    
    
}
