/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.io.File;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import label.LabelListController.label;
import section.SectionListController.section;
import task.TaskListController.task;

/**
 *
 * @author Chann
 */
public final class DatabaseHandler {
    private static DatabaseHandler handler = null;
    private static final String DB_URL = "jdbc:derby:taskDatabase;create=true";
    private static Connection conn=null;
    private static Statement stmt=null;
    
    private DatabaseHandler(){
        createConnection();
        setupSectionTable();
        setupLabelTable();
        setupTaskTable();
        setupLabelTaskTable();
        setupAttachmentTable();
        setupProgressTable();
    }
    public static DatabaseHandler getInstance(){
        if(handler == null){
            handler = new DatabaseHandler();
        }
        return handler;
    }
    
    
    void createConnection(){
        try {
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver").newInstance();
            conn = DriverManager.getConnection(DB_URL);
        } catch (Exception e) {
            e.printStackTrace();
        }
    
    }
    
    void setupSectionTable(){
    
        String TABLE_NAME = "section";
        
        try {
            stmt = conn.createStatement();
            DatabaseMetaData dmt = conn.getMetaData();
            ResultSet tables = dmt.getTables(null,null, TABLE_NAME.toUpperCase(), null);
            
            if(tables.next()){
                System.out.println("Tables"+TABLE_NAME+" already exsists.Ready to go!");
            
            }else{
                stmt.execute("CREATE TABLE "+TABLE_NAME+"("
                        +"sectionId varchar(20) primary key,\n"
                        +"sectionName varchar(100)"
                        +")");
            }
            
            
        } catch (Exception e) {
            System.err.println(e.getMessage()+"...setup tables");
        }finally{
        }
    }
    
    void setupLabelTable(){
    
        String TABLE_NAME = "label";
        
        try {
            stmt = conn.createStatement();
            DatabaseMetaData dmt = conn.getMetaData();
            ResultSet tables = dmt.getTables(null,null, TABLE_NAME.toUpperCase(), null);
            
            if(tables.next()){
                System.out.println("Tables"+TABLE_NAME+" already exsists.Ready to go!");
                //stmt.execute("DROP TABLE "+TABLE_NAME+"");
                //System.out.println("label deleted");
            
            }else{
                stmt.execute("CREATE TABLE "+TABLE_NAME+"("
                        +"labelId varchar(20) primary key,\n"
                        +"labelName varchar(100),\n"
                        +"labelColor varchar(100)"
                        +")");
            }
            
            
        } catch (Exception e) {
            System.err.println(e.getMessage()+"...setup tables");
        }finally{
        }
    }
    
    
    void setupTaskTable(){
    
        String TABLE_NAME = "task";
        
        try {
            stmt = conn.createStatement();
            DatabaseMetaData dmt = conn.getMetaData();
            ResultSet tables = dmt.getTables(null,null, TABLE_NAME.toUpperCase(), null);
            
            if(tables.next()){
                
                //stmt.execute("ALTER TABLE "+TABLE_NAME+" DROP CONSTRAINT FK_"+TABLE_NAME+"_section_sectionId");
                System.out.println("Tables"+TABLE_NAME+" already exsists.Ready to go!");
                //stmt.execute("DROP TABLE "+TABLE_NAME+"");
                
                //System.out.println("task deleted");
            }else{
                stmt.execute("CREATE TABLE "+TABLE_NAME+"("
                        +"tid varchar(20) primary key,\n"
                        +"tPriorityLevel varchar(20),\n"
                        +"taskName varchar(1000),\n"
                        +"taskDue varchar(100),\n"
                        +"sectionId varchar(20),\n"
                        +"taskdescription varchar(10000),\n"
                        +"FOREIGN KEY (sectionId) REFERENCES section(sectionId)"
                        +")");
            }
            
            
        } catch (Exception e) {
            System.err.println(e.getMessage()+"...setup tables");
        }finally{
        }
    }
    
    void setupLabelTaskTable(){
    
        String TABLE_NAME = "labelTask";
        
        try {
            stmt = conn.createStatement();
            DatabaseMetaData dmt = conn.getMetaData();
            ResultSet tables = dmt.getTables(null,null, TABLE_NAME.toUpperCase(), null);
            
            if(tables.next()){
                System.out.println("Tables"+TABLE_NAME+" already exsists.Ready to go!");
                
                
                //stmt.execute("DROP TABLE "+TABLE_NAME+"");
                //System.out.println("task deleted");
            }else{
                stmt.execute("CREATE TABLE "+TABLE_NAME+"("
                        +"tid varchar(20),\n"
                        +"labelNamed varchar(20)"
        
                        +")");
            }
            
            
        } catch (Exception e) {
            System.err.println(e.getMessage()+"...setup tables");
        }finally{
        }
    }
    void setupProgressTable(){
    
        String TABLE_NAME = "progressTable";
        
        try {
            stmt = conn.createStatement();
            DatabaseMetaData dmt = conn.getMetaData();
            ResultSet tables = dmt.getTables(null,null, TABLE_NAME.toUpperCase(), null);
            
            if(tables.next()){
                System.out.println("Tables"+TABLE_NAME+" already exsists.Ready to go!");
                
                
                //stmt.execute("DROP TABLE "+TABLE_NAME+"");
                //System.out.println("task deleted");
            }else{
                stmt.execute("CREATE TABLE "+TABLE_NAME+"("
                        +"tid varchar(20),\n"
                        +"completedTaskPriority varchar(100)"
        
                        +")");
            }
            
            
        } catch (Exception e) {
            System.err.println(e.getMessage()+"...setup tables");
        }finally{
        }
    }
    
    
    void setupAttachmentTable(){
    
        String TABLE_NAME = "attachment";
        
        try {
            stmt = conn.createStatement();
            DatabaseMetaData dmt = conn.getMetaData();
            ResultSet tables = dmt.getTables(null,null, TABLE_NAME.toUpperCase(), null);
            
            if(tables.next()){
                System.out.println("Tables"+TABLE_NAME+" already exsists.Ready to go!");
                //stmt.execute("DROP TABLE "+TABLE_NAME+"");
                //System.out.println("attachment deleted");
            }else{
                stmt.execute("CREATE TABLE "+TABLE_NAME+"("
                        +"attId varchar(20) primary key,\n"
                        +"attName varchar(500),\n"
                        +"attImage blob(200M),\n"
                        +"tid varchar(20),\n"                        
                        +"FOREIGN KEY (tid) REFERENCES task(tid)"
                        +")");
            }
            
            
        } catch (Exception e) {
            System.err.println(e.getMessage()+"...setup tables");
        }finally{
        }
    }
    
    public ImageIcon createBlob(String i) throws SQLException, IOException{
        
        Blob blob = conn.createBlob();
        ImageIcon ii = new ImageIcon(i);
        
        ObjectOutputStream oos;
        oos = new ObjectOutputStream(blob.setBinaryStream(1));
        oos.writeObject(ii);
        oos.close();
        
        return ii;
        
    }
    
    
    
    public ResultSet execQuery(String query){
        ResultSet result;
        
        try {
            stmt= conn.createStatement();
            result = stmt.executeQuery(query);
        } catch (Exception ex) {
            System.out.println("Exception at execQuery:databaseHAndler"+ex.getLocalizedMessage());
            return null;
        }finally{}
        return result;
        
    }
    
    public boolean execAction(String qu){
    
        try {
            stmt = conn.createStatement();
            stmt.execute(qu);
            return true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error Occured", JOptionPane.ERROR_MESSAGE);
            return false;
        }finally{}
    }
    
    
    public boolean deleteSection(section section) throws SQLException{
        try{
            String deleteStatement = "DELETE FROM section WHERE sectionId = ?";
            PreparedStatement psm = conn.prepareStatement(deleteStatement);
            psm.setString(1, section.getId());
            psm.executeUpdate();
            System.out.println("Deleted!!!");
            
            return true;
            
        }catch(Exception e){
            System.out.println(e);
        }
        return false;
    }
    
    public boolean updateSection(section section){
    
       String update = "UPDATE section SET sectionName=? WHERE sectionId=?";
        try {
            PreparedStatement pst = conn.prepareStatement(update);
            pst.setString(1, section.getName());
            pst.setString(2, section.getId());
            pst.executeUpdate();
             System.out.println("Updated succssfull");
            return true;
           
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
       
    }
    //************************************************************************************************************************
    public boolean deleteLabel(label label) throws SQLException{
        try{
            String deleteStatement = "DELETE FROM label WHERE labelId = ?";
            PreparedStatement psm = conn.prepareStatement(deleteStatement);
            psm.setString(1, label.getLid());
            psm.executeUpdate();
            System.out.println("Deleted!!!");
            return true;
            
        }catch(Exception e){
        
        }
        return false;
    }
    public boolean updateLabel(label label){
    
       String update = "UPDATE label SET labelName=?,labelColor=? WHERE labelId=?";
        try {
            PreparedStatement pst = conn.prepareStatement(update);
            pst.setString(1, label.getLname());
            pst.setString(2, label.getLcolor());
            pst.setString(3, label.getLid());
            pst.executeUpdate();
             System.out.println("Updated succssfull");
            return true;
           
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
       
    }
    
    //***********************************************************************************************
    public boolean deleteTask(task task) throws SQLException{
        try{
            String deleteStatement = "DELETE FROM task WHERE tid = ?";
            PreparedStatement psm = conn.prepareStatement(deleteStatement);
            psm.setString(1, task.getTid());
            psm.executeUpdate();
            System.out.println("Deleted!!!");
            return true;
            
        }catch(Exception e){
        
        }
        return false;
    }
     public boolean deleteTask2(String tID) throws SQLException{
        try{
            String deleteStatement = "DELETE FROM task WHERE tid='"+tID+"'";
            PreparedStatement psm = conn.prepareStatement(deleteStatement);
            psm.executeUpdate();
            System.out.println("Deleted!!!");
            return true;
            
        }catch(Exception e){
        
        }
        return false;
    }
    
    
    
    public boolean updateLabel(task task){
    
       String update = "UPDATE task SET taskName=?,tPriorityLevel=?,taskDue=?,taskSection=?,taskdescription=? WHERE tid=?,";
        try {
            PreparedStatement pst = conn.prepareStatement(update);
            pst.setString(1, task.getTname());
            pst.setString(2, task.gettPriority());
            pst.setString(3, task.getTdue());
            pst.setString(4, task.getTsec());
            pst.setString(5, task.getTdescrip());
            pst.setString(7, task.getTid());
            pst.executeUpdate();
             System.out.println("Updated succssfull");
            return true;
           
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
       
    }
    
    
}
