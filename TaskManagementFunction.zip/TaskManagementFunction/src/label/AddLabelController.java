/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package label;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXColorPicker;
import com.jfoenix.controls.JFXDialog;
import com.jfoenix.controls.JFXDialogLayout;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.events.JFXDialogEvent;
import database.DatabaseHandler;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.effect.BoxBlur;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 * @author Chann
 */
public class AddLabelController implements Initializable {
    private Boolean isInEditMode = Boolean.FALSE; 
    @FXML
    private JFXTextField labelName;
    @FXML
    private JFXColorPicker labelColorPicker;
    @FXML
    private JFXButton labelSave;
    @FXML
    private JFXButton labelCancel;
    DatabaseHandler databaseHandler;
    @FXML
    private JFXTextField labelId;
    @FXML
    private StackPane addLabelStackPane;
    @FXML
    private AnchorPane addLabelAnchor;
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void labelSaveAction(ActionEvent event) {
        
        databaseHandler = DatabaseHandler.getInstance();
        
        
        String lId = labelId.getText();
        String lNameText = labelName.getText();
        
        int color = labelColorPicker.getValue().hashCode();
    	String colorHex = Integer.toHexString(color);
        String colorCode = "#"+colorHex;
 
        if(lId.isEmpty()||lNameText.isEmpty()){
            loadDialogFailedEmpty();
            return;
        }
       
        if(isInEditMode){
            editedInsertion();
            return;
        }
        
        String qu = "INSERT INTO label VALUES("+
                "'"+lId+"',"+
                "'"+lNameText+"',"+
                "'"+colorCode+"'"+
                ")";
    
        if(databaseHandler.execAction(qu)){
            loadDialogSuccess();
        }else{
            loadDialogFailed();
        }
        
    }
    
    public void passData(LabelListController.label label){
        labelId.setText(label.getLid());
        labelName.setText(label.getLname());
        
        labelColorPicker.setValue(javafx.scene.paint.Color.web(label.getLcolor()));
        
        labelId.setEditable(false);
        isInEditMode = Boolean.TRUE;
    }

    private void editedInsertion() {
        
        int color = labelColorPicker.getValue().hashCode();
    	String colorHex = Integer.toHexString(color);
        String colorCode = "#"+colorHex;
    	
        LabelListController.label label = new LabelListController.label(labelId.getText(), labelName.getText(),colorCode);
        databaseHandler.updateLabel(label);
        
        if(databaseHandler.updateLabel(label)){
            loadDialogUpdateSuccess();
        }
        else{
            loadDialogUpdateFailed();
        }
        
    }    
        

    private void checkData() {
        String qu = "SELECT labelId FROM label";
        ResultSet rs = databaseHandler.execQuery(qu);
        try {
            while(rs.next()){
                String lName = rs.getString("labelId");
            }
        } catch (Exception e) {
            
        }
    }
    
    private void loadDialogFailedEmpty() {
        BoxBlur blur = new BoxBlur(3,3,3);
        JFXDialogLayout content = new JFXDialogLayout();
        content.getStyleClass().add("JFXDialogLayout");
        content.setHeading(new Text("One of the fields are empty!"+"\n"));
        content.setBody(new Text("New Label was not created.\n"
        +"Please check whether all fields are filled and try again."+"\n"));
        
        JFXDialog jd = new JFXDialog (addLabelStackPane,content,JFXDialog.DialogTransition.TOP);
        JFXButton button = new JFXButton("OK..I'll Check!");
        button.getStyleClass().add("okButton");
        button.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                jd.close();
            }
        
        });
        content.setActions(button);
        jd.setOnDialogClosed((JFXDialogEvent event1) -> {
            addLabelAnchor.setEffect(null);
        
        });
        addLabelAnchor.setEffect(blur);
        
        jd.show();    
    }
    
    private void loadDialogFailed() {
        BoxBlur blur = new BoxBlur(3,3,3);
        JFXDialogLayout content = new JFXDialogLayout();
        content.getStyleClass().add("JFXDialogLayout");
        content.setHeading(new Text("Label Creation Failed!"+"\n"));
        content.setBody(new Text("New Label was not created.\n"
        +"Please carefully check the entered details and try again."+"\n"));
        
        JFXDialog jd = new JFXDialog (addLabelStackPane,content,JFXDialog.DialogTransition.TOP);
        JFXButton button = new JFXButton("OK..I'll Check!");
        button.getStyleClass().add("okButton");
        button.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                jd.close();
            }
        
        });
        content.setActions(button);
        jd.setOnDialogClosed((JFXDialogEvent event1) -> {
            addLabelAnchor.setEffect(null);
        
        });
        addLabelAnchor.setEffect(blur);
        
        jd.show();    
    }
    
    private void loadDialogSuccess() {
        BoxBlur blur = new BoxBlur(3,3,3);
        JFXDialogLayout content = new JFXDialogLayout();
        content.getStyleClass().add("JFXDialogLayout");
        content.setHeading(new Text("New Label was Created!"+"\n"));
        content.setBody(new Text("New Label was created.\n"
        +"You can view any details about Labels by clicking the 'Select Labels' button"+"\n"));
        
        JFXDialog jd = new JFXDialog (addLabelStackPane,content,JFXDialog.DialogTransition.TOP);
        JFXButton button = new JFXButton("OK..Got it!");
        button.getStyleClass().add("okButton");
        button.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                jd.close();
            }
        
        });
        content.setActions(button);
        jd.setOnDialogClosed((JFXDialogEvent event1) -> {
            addLabelAnchor.setEffect(null);
        
        });
        addLabelAnchor.setEffect(blur);
        
        jd.show();    
    }

    private void loadDialogUpdateSuccess() {
       BoxBlur blur = new BoxBlur(3,3,3);
        JFXDialogLayout content = new JFXDialogLayout();
        content.getStyleClass().add("JFXDialogLayout");
        content.setHeading(new Text("Label was Updated!"+"\n"));
        content.setBody(new Text("Label was updated successfully!\n"
        +"You can view updated details on the table."+"\n"));
        
        JFXDialog jd = new JFXDialog (addLabelStackPane,content,JFXDialog.DialogTransition.TOP);
        JFXButton button = new JFXButton("OK..Got it!");
        button.getStyleClass().add("okButton");
        button.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                jd.close();
            }
        
        });
        content.setActions(button);
        jd.setOnDialogClosed((JFXDialogEvent event1) -> {
            addLabelAnchor.setEffect(null);
        
        });
        addLabelAnchor.setEffect(blur);
        
        jd.show(); 
    }

    private void loadDialogUpdateFailed() {
        BoxBlur blur = new BoxBlur(3,3,3);
        JFXDialogLayout content = new JFXDialogLayout();
        content.getStyleClass().add("JFXDialogLayout");
        content.setHeading(new Text("Label Update Failed!"+"\n"));
        content.setBody(new Text("Label was not updated.\n"
        +"Please carefully check the entered details and try again."+"\n"));
        
        JFXDialog jd = new JFXDialog (addLabelStackPane,content,JFXDialog.DialogTransition.TOP);
        JFXButton button = new JFXButton("OK..I'll Check!");
        button.getStyleClass().add("okButton");
        button.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                jd.close();
            }
        
        });
        content.setActions(button);
        jd.setOnDialogClosed((JFXDialogEvent event1) -> {
            addLabelAnchor.setEffect(null);
        
        });
        addLabelAnchor.setEffect(blur);
        
        jd.show();     }
    
}
