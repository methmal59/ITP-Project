/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package label;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXListView;
import com.jfoenix.controls.JFXToggleButton;
import database.DatabaseHandler;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import section.AddSectionController;
import section.SectionListController;
import task.AddTaskController;

/**
 * FXML Controller class
 *
 * @author Chann
 */
public class LabelListController implements Initializable {

    @FXML
    private TableView<label> label_table_view;
    @FXML
    private TableColumn<label, String> lid_col;
    @FXML
    private TableColumn<label, String> lname_col;
    @FXML
    private TableColumn<label, String> lcolor_col;

    ObservableList<label> list = FXCollections.observableArrayList();
    public static ObservableList<String> list2 = FXCollections.observableArrayList();
    
    @FXML
    private JFXListView<HBox> labelListView;
    @FXML
    private JFXButton labelOK;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        initializeColumns();
        loadData();
    }   
    
    private void initializeColumns() {
        
        lid_col.setCellValueFactory(new PropertyValueFactory<>("lid"));
        lname_col.setCellValueFactory(new PropertyValueFactory<>("lname"));
        lcolor_col.setCellValueFactory(new PropertyValueFactory<>("lcolor"));
        
    }
    private void loadData() {
        list.clear();
        labelListView.getItems().clear();
        DatabaseHandler databaseHandler = DatabaseHandler.getInstance();
        
        String qu = "SELECT * FROM label";
        ResultSet rs = databaseHandler.execQuery(qu);
        try {
            while(rs.next()){
                String labelId = rs.getString("labelId");
                String labelName = rs.getString("labelName");
                String labelColor = rs.getString("labelColor");
                System.out.println(labelName+labelId+labelColor);
                
                label l = new label(labelId,labelName,labelColor);
                System.out.println(l.getLname());
                list.add(l);
                
                HBox lh = new HBox();
                //lh.setStyle("-fx-padding:px;");
                JFXToggleButton tb1 = new JFXToggleButton();
                tb1.setStyle("-fx-pref-width:100px;");
                
                
                tb1.setOnAction(new EventHandler<ActionEvent>(){
                
                @Override public void handle(ActionEvent e){
                
                        
                        //list2.add(tb1);
                        
                        

                    }
                });
                
                
                 
                
                //String colorCodeStatement = "-fx-background-color: "+colorCode+";";
                tb1.setStyle("-fx-background-color:"+labelColor);
                
                
                tb1.setText(labelName);

                lh.getChildren().add(tb1);
                labelListView.getItems().add(lh);
                
               
            
            }
        } catch (Exception e) {
            
        }
        
        label_table_view.setItems(list);
        
    }
    

    @FXML
    private void refreshLabelTable(ActionEvent event) {
        loadData();
    }

    @FXML
    private void editLabel(ActionEvent event) {
        
        
        LabelListController.label selectedLabel = label_table_view.getSelectionModel().getSelectedItem();
        
        if(selectedLabel == null){
            System.out.println("selected Label is empty!");
            return;
        }
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/label/addLabel.fxml"));
            Parent addNewLabelUI = loader.load();
            
            AddLabelController controller = loader.getController();
            controller.passData(selectedLabel);
       
        
            Stage addNewLabelStage = new Stage(StageStyle.UNIFIED);
            Scene addNewLabelScene = new Scene(addNewLabelUI);
            addNewLabelStage.setScene(addNewLabelScene);
            addNewLabelStage.show();
            
            addNewLabelStage.setOnCloseRequest((e)->{
                
                refreshLabelTable(new ActionEvent());
            
            });
            
            
        } catch (Exception e) {
        }
    }

    @FXML
    private void deleteLabel(ActionEvent event) throws SQLException {
        
        LabelListController.label selectedLabel = label_table_view.getSelectionModel().getSelectedItem();
        
        if(selectedLabel == null){
            System.out.println("selected Section is empty!");
            return;
        }
        //here show alert of confirmation
        //then use if to checkanswer 24
        boolean result = DatabaseHandler.getInstance().deleteLabel(selectedLabel);
        if(result){
            System.out.println("Deleted methods ran success!");
            list.remove(selectedLabel);
        }else{
            System.out.println("deletion method run unsucess");
        }
        
    }

    @FXML
    private void labelOKAction(ActionEvent event) {
        
        int loopSize = list.size();
        
        for(int i =0;i<loopSize;i++){
            labelListView.getSelectionModel().select(i);
            HBox newH = new HBox();
            newH = labelListView.getSelectionModel().getSelectedItem();
            JFXToggleButton newTB = new JFXToggleButton();
            newTB = (JFXToggleButton) newH.getChildren().get(0);
            System.out.println(newTB.getText());//*********************************
            
            if(newTB.isSelected()){
                list2.add(newTB.getText());
            }
           
        }
        System.out.println(list2);//***************************************************
        
        
        
    }

  
    
    
   
        
    public static class label{
        private final SimpleStringProperty lid;
        private final SimpleStringProperty lname;
        private final SimpleStringProperty lcolor;
        
        label(String lid,String lname,String lcolor){
            this.lid = new SimpleStringProperty(lid);
            this.lname = new SimpleStringProperty(lname);
            this.lcolor = new SimpleStringProperty(lcolor);
        }

        public String getLid() {
            return lid.get();
        }

        public String getLname() {
            return lname.get();
        }

        public String getLcolor() {
            return lcolor.get();
        }

        
        
        
    }
    
}
