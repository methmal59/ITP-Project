

package empreg;


public class User {
    
    private String pid;
    private String pname;
    private String empid;
    private String fname;
    private String lname;
    private String cno;
    private String nno;
    private String ad;
    private String status;
    private byte[] person_image=null;
    private String pot;
    
    public User( String Pid,String Pname,String Empid,String Fname,String Lname,String Cno,byte[]Person_image,String Ad,String Status,String Nno,String Pot){
    
    this.pid=Pid;
    this.pname=Pname;
    this.empid=Empid;
    this.fname=Fname;
    this.lname=Lname;
    this.cno=Cno;
    this.person_image=Person_image;
    this.nno=Nno;
    this.ad=Ad;
    this.status=Status;
    this.pot=Pot;
    }

    User(String string, String string0, String string1, String string2, String string3, String string4) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public String getPid(){
        return pid;
    }
    public String getPname(){
        return pname;
    }
    public String getEmpid(){
        return empid;
    }
    
    public String getFname(){
        return fname;
    }
    public String getLname(){
        return lname;
    }
    public String getCno(){
        return cno;
    }
    public byte[] getPerson_image(){
        return person_image;
    }
    public String getAd(){
        return ad;
    }
    public String getPot(){
        return pot;
    }
    public String getNno(){
        return nno;
    }
    public String getStatus(){
        return status;
    }
}
