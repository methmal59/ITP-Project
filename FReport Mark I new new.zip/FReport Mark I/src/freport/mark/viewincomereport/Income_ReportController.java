package freport.mark.viewincomereport;

import freport.mark.database.dataBaseHandler;
import freport.mark.i.FXMLDocumentController;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.print.PageLayout;
import javafx.print.PageOrientation;
import javafx.print.Paper;
import javafx.print.Printer;
import javafx.print.PrinterJob;
import javafx.scene.Node;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.transform.Scale;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;


public class Income_ReportController implements Initializable {
    
    ObservableList<IncomeReport> list = FXCollections.observableArrayList();

    @FXML
    private TableColumn<IncomeReport, String> idCol;
    @FXML
    private TableColumn<IncomeReport, String> monthCol;
    @FXML
    private TableColumn<IncomeReport, String> categoryCol;
    @FXML
    private TableColumn<IncomeReport, String> amountCol;
    @FXML
    private TableView<IncomeReport> incomeTable;
    @FXML
    private AnchorPane rootpane;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initCol();
        
        loadDataI();
    }    

    @FXML
    private void loadPrint(ActionEvent event) {
       //print(incomeTable);
       print(incomeTable);
    }

    @FXML
    private void loadExport(ActionEvent event) {
        IncometoExcel();
    }

    private void initCol() {
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        monthCol.setCellValueFactory(new PropertyValueFactory<>("month"));
        categoryCol.setCellValueFactory(new PropertyValueFactory<>("category"));
        amountCol.setCellValueFactory(new PropertyValueFactory<>("amount"));
    }

    private void loadDataI() {
        list.clear();
        
        dataBaseHandler handler = new dataBaseHandler();
        String qu = "SELECT * FROM INCOME";
        ResultSet rs = handler.execQuery(qu);
        try {
            while(rs.next()){
                String id = rs.getString("id");
                String month = rs.getString("date");
                String category = rs.getString("category");
                String amount = rs.getString("amount");
                
                list.add(new IncomeReport(id, month, category, amount));
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        incomeTable.getItems().setAll(list);
    }

    @FXML
    private void refreshTable(ActionEvent event) {
        loadDataI();
    }
    
    public static class IncomeReport{
        private final SimpleStringProperty id;
        private final SimpleStringProperty month;
        private final SimpleStringProperty category;
        private final SimpleStringProperty amount;
        
        IncomeReport(String id, String month, String category, String amount ){
            this.id = new SimpleStringProperty(id);
            this.month = new SimpleStringProperty(month);
            this.category = new SimpleStringProperty(category);
            this.amount = new SimpleStringProperty(amount);
        }

        public String getId() {
            return id.get();
        }

        public String getMonth() {
            return month.get();
        }

        public String getCategory() {
            return category.get();
        }

        public String getAmount() {
            return amount.get();
        }
        
        
    }
    
    public void print(final Node node){
        Printer printer = Printer.getDefaultPrinter();
        PageLayout pageLayout = printer.createPageLayout(Paper.A4, PageOrientation.PORTRAIT, Printer.MarginType.DEFAULT);
        double scaleX = pageLayout.getPrintableWidth() / node.getBoundsInParent().getWidth();
        double scaleY = pageLayout.getPrintableHeight() / node.getBoundsInParent().getHeight();
        node.getTransforms().add(new Scale(scaleX, scaleY));
    
        PrinterJob job =  PrinterJob.createPrinterJob();
        if(job != null){
            boolean success = job.printPage(node);
            if (success){
                job.endJob();
            }
        }
    }
    
    public void IncometoExcel(){   
    //try {   
            try {
                int counter = 1;
                FileOutputStream fileOut = null;
                dataBaseHandler ihandler = new dataBaseHandler();
                String iq1 = "SELECT * FROM INCOME";
                String filename = "D:/Income.xls" ;
                //Creation of New Work Book in Excel and sheet.
                HSSFWorkbook hwb = new HSSFWorkbook();
                HSSFSheet sheet = hwb.createSheet("new sheet");
                //Creating Headings in Excel sheet.
                HSSFRow rowhead=  sheet.createRow((short)0);
                rowhead.createCell((short) 0).setCellValue("Income ID");//Row Name1
                rowhead.createCell((short) 1).setCellValue("Income Date");//Row Name2
                rowhead.createCell((short) 2).setCellValue("Income Description");//Row Name3
                rowhead.createCell((short) 3).setCellValue("Income Amount");//Row Name4
                ResultSet irs = ihandler.execQuery(iq1);
                while(irs.next()){
                    //Insertion in corresponding row
                    HSSFRow row=  sheet.createRow((int)counter);
                  
                    row.createCell((short) 0).setCellValue(irs.getString("id"));
                    row.createCell((short) 1).setCellValue(irs.getString("date"));
                    row.createCell((short) 2).setCellValue(irs.getString("category"));
                    row.createCell((short) 3).setCellValue(irs.getString("amount"));
                    counter ++;
                    try {
                        //For performing write to Excel file
                        fileOut = new FileOutputStream(filename);
                        hwb.write(fileOut);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                //Close all the parameters once writing to excel is compelte.
                fileOut.close();    
                irs.close();
            } catch (IOException ex) {
                Logger.getLogger(Income_ReportController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
            Logger.getLogger(Income_ReportController.class.getName()).log(Level.SEVERE, null, ex);
        }
     } 

    }
    