
package freport.mark.viewexpensereport;

import freport.mark.database.dataBaseHandler;
import freport.mark.i.FXMLDocumentController;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.print.PageLayout;
import javafx.print.PageOrientation;
import javafx.print.Paper;
import javafx.print.Printer;
import javafx.print.PrinterJob;
import javafx.scene.Node;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.transform.Scale;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;


public class Expense_ReportController implements Initializable {
    
    ObservableList<ExpenseReport> list = FXCollections.observableArrayList();

    @FXML
    private TableView<ExpenseReport> expenseTable;
    @FXML
    private TableColumn<ExpenseReport, String> eidCol;
    @FXML
    private TableColumn<ExpenseReport, String> emonthCol;
    @FXML
    private TableColumn<ExpenseReport, String> ecategoryCol;
    @FXML
    private TableColumn<ExpenseReport, String> eamountCol;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initCol();
        
        loadDataE();
    }    

    @FXML
    private void loadPrint(ActionEvent event) {
        print(expenseTable);
    }

    @FXML
    private void loadExport(ActionEvent event) {
        ExpensetoExcel();
    }

    private void initCol() {
        eidCol.setCellValueFactory(new PropertyValueFactory<>("eid"));
        emonthCol.setCellValueFactory(new PropertyValueFactory<>("emonth"));
        ecategoryCol.setCellValueFactory(new PropertyValueFactory<>("ecategory"));
        eamountCol.setCellValueFactory(new PropertyValueFactory<>("eamount"));
    }

    private void loadDataE() {
        list.clear();
        
        dataBaseHandler handler1 = new dataBaseHandler();
        String st = "SELECT * FROM EXPENSE";
        ResultSet rs = handler1.execQuery(st);
        try {
            while(rs.next()){
                String eid = rs.getString("eid");
                String emonth = rs.getString("edate");
                String ecategorye = rs.getString("ecategory");
                String eamount = rs.getString("eamount");
                
                list.add(new ExpenseReport(eid, emonth, ecategorye, eamount));
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        expenseTable.getItems().setAll(list);
        
    }

    @FXML
    private void refreshExpense(ActionEvent event) {
        loadDataE();
    }
    
    public static class ExpenseReport{
        private final SimpleStringProperty eid;
        private final SimpleStringProperty emonth;
        private final SimpleStringProperty ecategory;
        private final SimpleStringProperty eamount;
        
        ExpenseReport(String eid, String emonth, String ecategory, String eamount ){
            this.eid = new SimpleStringProperty(eid);
            this.emonth = new SimpleStringProperty(emonth);
            this.ecategory = new SimpleStringProperty(ecategory);
            this.eamount = new SimpleStringProperty(eamount);
        }

        public String getEid() {
            return eid.get();
        }

        public String getEmonth() {
            return emonth.get();
        }

        public String getEcategory() {
            return ecategory.get();
        }

        public String getEamount() {
            return eamount.get();
        } 
    }
    
    public void print(final Node node){
        Printer printer = Printer.getDefaultPrinter();
        PageLayout pageLayout = printer.createPageLayout(Paper.A4, PageOrientation.PORTRAIT, Printer.MarginType.DEFAULT);
        double scaleX = pageLayout.getPrintableWidth() / node.getBoundsInParent().getWidth();
        double scaleY = pageLayout.getPrintableHeight() / node.getBoundsInParent().getHeight();
        node.getTransforms().add(new Scale(scaleX, scaleY));
    
        PrinterJob job =  PrinterJob.createPrinterJob();
        if(job != null){
            boolean success = job.printPage(node);
            if (success){
                job.endJob();
            }
        }
    }
    
    public void ExpensetoExcel(){
            try {
                int counter = 1;
                FileOutputStream fileOut = null;
                dataBaseHandler ehandler = new dataBaseHandler();
                String eq1 = "SELECT * FROM EXPENSE";
                String filename = "D:/Expense.xls" ;
                //Creation of New Work Book in Excel and sheet.
                HSSFWorkbook hwb = new HSSFWorkbook();
                HSSFSheet sheet = hwb.createSheet("new sheet");
                //Creating Headings in Excel sheet.
                HSSFRow rowhead=  sheet.createRow((short)0);
                rowhead.createCell((short) 0).setCellValue("Expense ID");//Row Name1
                rowhead.createCell((short) 1).setCellValue("Expense Date");//Row Name2
                rowhead.createCell((short) 2).setCellValue("Expense Description");//Row Name3
                rowhead.createCell((short) 3).setCellValue("Expense Amount");//Row Name4
                ResultSet ers = ehandler.execQuery(eq1);
                while(ers.next()){
                    //Insertion in corresponding row
                    HSSFRow row=  sheet.createRow((int)counter);
                   
                    row.createCell((short) 0).setCellValue(ers.getString("eid"));
                    row.createCell((short) 1).setCellValue(ers.getString("edate"));
                    row.createCell((short) 2).setCellValue(ers.getString("ecategory"));
                    row.createCell((short) 3).setCellValue(ers.getString("eamount"));
                    counter ++;
                    try {
                        //For performing write to Excel file
                        fileOut = new FileOutputStream(filename);
                        hwb.write(fileOut);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                //Close all the parameters once writing to excel is compelte.
                fileOut.close();    
                ers.close(); 
            }catch (IOException ex) {
                Logger.getLogger(Expense_ReportController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
            Logger.getLogger(Expense_ReportController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}

