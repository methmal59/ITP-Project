
package freport.mark.e;

import freport.mark.database.dataBaseHandler;
import freport.mark.i.FXMLDocumentController;
import freport.mark.listexpenses.ExpensesListController;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


public class ExpenseAddController implements Initializable {

    dataBaseHandler handler1;
    
    @FXML
    private TextField eid;
    @FXML
    private TextField ecategory;
    @FXML
    private TextField eamount;
    @FXML
    private Button saveButton;
    @FXML
    private Button cancelButton;
    @FXML
    private AnchorPane rootPane;
    @FXML
    private TextField emonth;
    
    private Boolean isInEditMode = Boolean.FALSE;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        handler1 = dataBaseHandler.getInstance();
        checkData();
    }    

    @FXML
    private void addExpense(ActionEvent event) {
        String expenseID = eid.getText();
        String expenseDate = emonth.getText();
        String expenseCategory = ecategory.getText();
        String expenseAmount = eamount.getText();
        
        
        if(expenseID.isEmpty()||expenseDate.isEmpty()||expenseCategory.isEmpty()||expenseAmount.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Please Enter in all feilds");
            alert.showAndWait();
            return;
        }
        
        if(isInEditMode){
            handleEditOperation();
            return;
        }
        
        String st = "INSERT INTO EXPENSE VALUES (" 
               + "'"+ expenseID +"',"
               + "'"+ expenseDate +"',"
               + "'"+ expenseCategory +"',"
               + "'"+ expenseAmount +"'"
               + ")";
        System.out.println(st);
        if(handler1.execAction(st)){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText("Success");
            alert.showAndWait();
        }
        else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Error Occured");
            alert.showAndWait();
        }
    }

    @FXML
    private void cancel(ActionEvent event) {
        Stage stage = (Stage) rootPane.getScene().getWindow();
        stage.close();
    }
    
    private void checkData() {
        String st = "SELECT ecategory FROM EXPENSE";
        ResultSet rs = handler1.execQuery(st);
        try {
            while(rs.next()){
                String ecategoryex = rs.getString("ecategory");
                System.out.println(ecategoryex);
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void inflateUI(ExpensesListController.Expense expense ){
    
        eid.setText(expense.getEid());
        emonth.setText(expense.getEdate());
        ecategory.setText(expense.getEcategory());
        eamount.setText(expense.getEamount());
        eid.setEditable(false);
        isInEditMode = Boolean.TRUE;
    }

    private void handleEditOperation() {
        ExpensesListController.Expense expense = new ExpensesListController.Expense(eid.getText(), emonth.getText(), ecategory.getText(), eamount.getText());
        if(handler1.updateExpense(expense)){
             Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                alert1.setTitle("Success");
                alert1.setContentText("Expense Updated.");
        }
        else{
             Alert alert2 = new Alert(Alert.AlertType.ERROR);
                    alert2.setTitle("Failed");
                    alert2.setHeaderText("could not be updated.");
        }
    }
    
}
