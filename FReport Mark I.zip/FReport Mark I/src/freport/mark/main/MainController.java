
package freport.mark.main;

import freport.mark.database.dataBaseHandler;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;
import javafx.stage.StageStyle;


public class MainController implements Initializable {

    
    @FXML
    private BarChart<?, ?> comparatorChart;
    @FXML
    private NumberAxis yAxis;
    @FXML
    private CategoryAxis xAxis;
    
    @FXML
    private LineChart<?, ?> positionChart;
    @FXML
    private NumberAxis yfAxis;
    @FXML
    private CategoryAxis xfAxis;
    
    public int j1;
    public int f1;
    public int ma1;
    public int a1;
    public int may1;
    public int ju1;
    public int july1;
    public int au1;
    public int se1;
    public int o1;
    public int n1;
    public int d1;
    
    public int ej1;
    public int ef1;
    public int ema1;
    public int ea1;
    public int emay1;
    public int eju1;
    public int ejuly1;
    public int eau1;
    public int ese1;
    public int eo1;
    public int en1;
    public int ed1;
    
    @FXML
    private PieChart incomePieChart;
    @FXML
    private PieChart expensePieChart;
    @FXML
    private PieChart profitPieChart;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
        loaddata1();
        incomeGraph();
        expenseGraph();
        incomePosition();
        expensePosition();
        incomePie();
        expensePie();
        totalPie();
          
    }    

    @FXML
    private void loadAddIncome(ActionEvent event) {
        loadWindow("/freport/mark/i/FXMLDocument.fxml", "Add New Income");
    }

    @FXML
    private void loadViewIncome(ActionEvent event) {
        loadWindow("/freport/mark/listincome/income_list.fxml", "Income List");
    }

    @FXML
    private void loadAddExpense(ActionEvent event) {
        loadWindow("/freport/mark/e/expense_add.fxml", "Add New Expense");
    }

    @FXML
    private void loadViewExpenses(ActionEvent event) {
        loadWindow("/freport/mark/listexpenses/Expenses_list.fxml", "Expenses List");
    }

    @FXML
    private void loadPrintReport(ActionEvent event) {
        MessageFormat header = new MessageFormat("Financial Report Details");
        MessageFormat footer = new MessageFormat("page(0,number,integer)");
        
        
    }

    @FXML
    private void loadSendReport(ActionEvent event) {
    }
    
      
    void loadWindow(String loc, String title){
    
        try {
            Parent parent = FXMLLoader.load(getClass().getResource(loc) );
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle(title);
            stage.setScene(new Scene(parent));
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(MainController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void loaddata1(){
	dataBaseHandler handler = dataBaseHandler.getInstance();
	String qu = "SELECT * FROM INCOME";
	ResultSet rs = handler.execQuery(qu);
	int count = 0;	
        try{
            while(rs.next()) {
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count = count + x;
            }
        }catch (SQLException ex) {
            
        }

	System.out.println("Total Income "+count);
        System.out.println("");
    }
    
    private void incomeGraph(){
        
        
        dataBaseHandler databasehandler1 = dataBaseHandler.getInstance();
	String qu1 = "SELECT * FROM INCOME";
	ResultSet rs = databasehandler1.execQuery(qu1);
	
        int count1 = 0;
        int count2 = 0;
        int count3 = 0;
        int count4 = 0;
        int count5 = 0;
        int count6 = 0;
        int count7 = 0;
        int count8 = 0;
        int count9 = 0;
        int count10 = 0;
        int count11 = 0;
        int count12 = 0;
        
        try{
            while(rs.next()) {
                String m1 = rs.getString("date");
                if("january".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count1 = count1 + x;
                    j1 = count1;
                    
                }else if("february".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count2 = count2 + x;
                    f1 = count2;
                    
                }else if("march".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count3 = count3 + x;
                    ma1 = count3; 
                    
                }else if("april".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count4 = count4 + x;
                    a1 = count4;
                    
                }else if("may".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count5 = count5 + x;
                    may1 = count5;
                    
                }else if("june".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count6 = count6 + x;
                    ju1 = count6;
                    
                }else if("july".equals(m1) || "July".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count7 = count7 + x;
                    july1 = count7;
                    
                }else if("august".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count8 = count8 + x;
                    au1 = count8;
                    
                }else if("september".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count9 = count9 + x;
                    se1 = count9;
                    
                }else if("october".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count10 = count10 + x;
                    o1 = count10;
                    
                }else if("november".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count11 = count11 + x;
                    n1 = count11;
                    
                }else if("december".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count12 = count12 + x;
                    d1 = count12;
                    
                }else{}
                
            }
        }catch (SQLException ex) {
            
        }
        System.out.println(j1);
        System.out.println(f1);
        System.out.println(ma1);
        System.out.println(a1);
        System.out.println(may1);
        System.out.println(ju1);
        System.out.println(july1);
        System.out.println(au1);
        System.out.println(se1);
        System.out.println(o1);
        System.out.println(n1);
        System.out.println(d1);
        System.out.println("");
        
        XYChart.Series set1 = new XYChart.Series<>();
        set1.setName("Income");
        set1.getData().add(new XYChart.Data("January",j1));
        set1.getData().add(new XYChart.Data("February",f1));
        set1.getData().add(new XYChart.Data("March",ma1));
        set1.getData().add(new XYChart.Data("April",a1));
        set1.getData().add(new XYChart.Data("May",may1));
        set1.getData().add(new XYChart.Data("June",ju1));
        set1.getData().add(new XYChart.Data("July",july1));
        set1.getData().add(new XYChart.Data("August",au1));
        set1.getData().add(new XYChart.Data("September",se1));
        set1.getData().add(new XYChart.Data("October",o1));
        set1.getData().add(new XYChart.Data("November",n1));
        set1.getData().add(new XYChart.Data("December",d1));
        comparatorChart.getData().addAll(set1);
    }

    @FXML
    private void refreshComparator(ActionEvent event) {
        comparatorChart.getData().clear();
        comparatorChart.getData().clear();
        incomeGraph();
        
        expenseGraph();
    }
    
    private void expenseGraph(){
        
        
        dataBaseHandler databasehandler2 = dataBaseHandler.getInstance();
	String qu2 = "SELECT * FROM EXPENSE";
	ResultSet rs2 = databasehandler2.execQuery(qu2);
	
        int count1 = 0;
        int count2 = 0;
        int count3 = 0;
        int count4 = 0;
        int count5 = 0;
        int count6 = 0;
        int count7 = 0;
        int count8 = 0;
        int count9 = 0;
        int count10 = 0;
        int count11 = 0;
        int count12 = 0;
        
        try{
            while(rs2.next()) {
                String m1 = rs2.getString("edate");
                if("january".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count1 = count1 + x;
                    ej1 = count1;
                    
                }else if("february".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count2 = count2 + x;
                    ef1 = count2;
                    
                }else if("march".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count3 = count3 + x;
                    ema1 = count3; 
                    
                }else if("april".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count4 = count4 + x;
                    ea1 = count4;
                    
                }else if("may".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count5 = count5 + x;
                    emay1 = count5;
                    
                }else if("june".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count6 = count6 + x;
                    eju1 = count6;
                    
                }else if("july".equals(m1) || "July".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count7 = count7 + x;
                    ejuly1 = count7;
                    
                }else if("august".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count8 = count8 + x;
                    eau1 = count8;
                    
                }else if("september".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count9 = count9 + x;
                    ese1 = count9;
                    
                }else if("october".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count10 = count10 + x;
                    eo1 = count10;
                    
                }else if("november".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count11 = count11 + x;
                    en1 = count11;
                    
                }else if("december".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count12 = count12 + x;
                    ed1 = count12;
                    
                }else{}
                
            }
        }catch (SQLException ex) {
            
        }
        System.out.println(ej1);
        System.out.println(ef1);
        System.out.println(ema1);
        System.out.println(ea1);
        System.out.println(emay1);
        System.out.println(eju1);
        System.out.println(ejuly1);
        System.out.println(eau1);
        System.out.println(ese1);
        System.out.println(eo1);
        System.out.println(en1);
        System.out.println(ed1);
        
        XYChart.Series set2 = new XYChart.Series<>();
        set2.setName("Expense");
        set2.getData().add(new XYChart.Data("January",ej1));
        set2.getData().add(new XYChart.Data("February",ef1));
        set2.getData().add(new XYChart.Data("March",ema1));
        set2.getData().add(new XYChart.Data("April",ea1));
        set2.getData().add(new XYChart.Data("May",emay1));
        set2.getData().add(new XYChart.Data("June",eju1));
        set2.getData().add(new XYChart.Data("July",ejuly1));
        set2.getData().add(new XYChart.Data("August",eau1));
        set2.getData().add(new XYChart.Data("September",ese1));
        set2.getData().add(new XYChart.Data("October",eo1));
        set2.getData().add(new XYChart.Data("November",en1));
        set2.getData().add(new XYChart.Data("December",ed1));
        comparatorChart.getData().addAll(set2);
    }

    @FXML
    private void refreshPosition(ActionEvent event) {
        positionChart.getData().clear();
        positionChart.getData().clear();
        incomePosition();
        
        expensePosition();
    }
    
    private void incomePosition(){
        dataBaseHandler databasehandler3 = dataBaseHandler.getInstance();
	String qu3 = "SELECT * FROM INCOME";
	ResultSet rs3 = databasehandler3.execQuery(qu3);
	
        int count1 = 0;
        int count2 = 0;
        int count3 = 0;
        int count4 = 0;
        int count5 = 0;
        int count6 = 0;
        int count7 = 0;
        int count8 = 0;
        int count9 = 0;
        int count10 = 0;
        int count11 = 0;
        int count12 = 0;
        
        try{
            while(rs3.next()) {
                String m1 = rs3.getString("date");
                if("january".equals(m1)){
                    String newamount = rs3.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count1 = count1 + x;
                    j1 = count1;
                    
                }else if("february".equals(m1)){
                    String newamount = rs3.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count2 = count2 + x;
                    f1 = count2;
                    
                }else if("march".equals(m1)){
                    String newamount = rs3.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count3 = count3 + x;
                    ma1 = count3; 
                    
                }else if("april".equals(m1)){
                    String newamount = rs3.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count4 = count4 + x;
                    a1 = count4;
                    
                }else if("may".equals(m1)){
                    String newamount = rs3.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count5 = count5 + x;
                    may1 = count5;
                    
                }else if("june".equals(m1)){
                    String newamount = rs3.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count6 = count6 + x;
                    ju1 = count6;
                    
                }else if("july".equals(m1) || "July".equals(m1)){
                    String newamount = rs3.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count7 = count7 + x;
                    july1 = count7;
                    
                }else if("august".equals(m1)){
                    String newamount = rs3.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count8 = count8 + x;
                    au1 = count8;
                    
                }else if("september".equals(m1)){
                    String newamount = rs3.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count9 = count9 + x;
                    se1 = count9;
                    
                }else if("october".equals(m1)){
                    String newamount = rs3.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count10 = count10 + x;
                    o1 = count10;
                    
                }else if("november".equals(m1)){
                    String newamount = rs3.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count11 = count11 + x;
                    n1 = count11;
                    
                }else if("december".equals(m1)){
                    String newamount = rs3.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count12 = count12 + x;
                    d1 = count12;
                    
                }else{}
                
            }
        }catch (SQLException ex) {
            
        }
        
        XYChart.Series series1 = new XYChart.Series<>();
        series1.setName("Income");
        series1.getData().add(new XYChart.Data("January",j1));
        series1.getData().add(new XYChart.Data("February",f1));
        series1.getData().add(new XYChart.Data("March",ma1));
        series1.getData().add(new XYChart.Data("April",a1));
        series1.getData().add(new XYChart.Data("May",may1));
        series1.getData().add(new XYChart.Data("June",ju1));
        series1.getData().add(new XYChart.Data("July",july1));
        series1.getData().add(new XYChart.Data("August",au1));
        series1.getData().add(new XYChart.Data("September",se1));
        series1.getData().add(new XYChart.Data("October",o1));
        series1.getData().add(new XYChart.Data("November",n1));
        series1.getData().add(new XYChart.Data("December",d1));
        positionChart.getData().addAll(series1);
    }
    
    private void expensePosition(){
        dataBaseHandler databasehandler4 = dataBaseHandler.getInstance();
	String qu4 = "SELECT * FROM EXPENSE";
	ResultSet rs4 = databasehandler4.execQuery(qu4);
	
        int count1 = 0;
        int count2 = 0;
        int count3 = 0;
        int count4 = 0;
        int count5 = 0;
        int count6 = 0;
        int count7 = 0;
        int count8 = 0;
        int count9 = 0;
        int count10 = 0;
        int count11 = 0;
        int count12 = 0;
        
        try{
            while(rs4.next()) {
                String m1 = rs4.getString("edate");
                if("january".equals(m1)){
                    String newamount = rs4.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count1 = count1 + x;
                    ej1 = count1;
                    
                }else if("february".equals(m1)){
                    String newamount = rs4.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count2 = count2 + x;
                    ef1 = count2;
                    
                }else if("march".equals(m1)){
                    String newamount = rs4.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count3 = count3 + x;
                    ema1 = count3; 
                    
                }else if("april".equals(m1)){
                    String newamount = rs4.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count4 = count4 + x;
                    ea1 = count4;
                    
                }else if("may".equals(m1)){
                    String newamount = rs4.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count5 = count5 + x;
                    emay1 = count5;
                    
                }else if("june".equals(m1)){
                    String newamount = rs4.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count6 = count6 + x;
                    eju1 = count6;
                    
                }else if("july".equals(m1) || "July".equals(m1)){
                    String newamount = rs4.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count7 = count7 + x;
                    ejuly1 = count7;
                    
                }else if("august".equals(m1)){
                    String newamount = rs4.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count8 = count8 + x;
                    eau1 = count8;
                    
                }else if("september".equals(m1)){
                    String newamount = rs4.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count9 = count9 + x;
                    ese1 = count9;
                    
                }else if("october".equals(m1)){
                    String newamount = rs4.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count10 = count10 + x;
                    eo1 = count10;
                    
                }else if("november".equals(m1)){
                    String newamount = rs4.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count11 = count11 + x;
                    en1 = count11;
                    
                }else if("december".equals(m1)){
                    String newamount = rs4.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count12 = count12 + x;
                    ed1 = count12;
                    
                }else{}
                
            }
        }catch (SQLException ex) {
            
        }
        
        XYChart.Series series2 = new XYChart.Series<>();
        series2.setName("Expense");
        series2.getData().add(new XYChart.Data("January",ej1));
        series2.getData().add(new XYChart.Data("February",ef1));
        series2.getData().add(new XYChart.Data("March",ema1));
        series2.getData().add(new XYChart.Data("April",ea1));
        series2.getData().add(new XYChart.Data("May",emay1));
        series2.getData().add(new XYChart.Data("June",eju1));
        series2.getData().add(new XYChart.Data("July",ejuly1));
        series2.getData().add(new XYChart.Data("August",eau1));
        series2.getData().add(new XYChart.Data("September",ese1));
        series2.getData().add(new XYChart.Data("October",eo1));
        series2.getData().add(new XYChart.Data("November",en1));
        series2.getData().add(new XYChart.Data("December",ed1));
        positionChart.getData().addAll(series2);
    }
    
    private void incomePie(){
        dataBaseHandler databasehandler1 = dataBaseHandler.getInstance();
	String qu1 = "SELECT * FROM INCOME";
	ResultSet rs = databasehandler1.execQuery(qu1);
	
        int count1 = 0;
        int count2 = 0;
        int count3 = 0;
        int count4 = 0;
        int count5 = 0;
        int count6 = 0;
        int count7 = 0;
        int count8 = 0;
        int count9 = 0;
        int count10 = 0;
        int count11 = 0;
        int count12 = 0;
        
        try{
            while(rs.next()) {
                String m1 = rs.getString("date");
                if("january".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count1 = count1 + x;
                    j1 = count1;
                    
                }else if("february".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count2 = count2 + x;
                    f1 = count2;
                    
                }else if("march".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count3 = count3 + x;
                    ma1 = count3; 
                    
                }else if("april".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count4 = count4 + x;
                    a1 = count4;
                    
                }else if("may".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count5 = count5 + x;
                    may1 = count5;
                    
                }else if("june".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count6 = count6 + x;
                    ju1 = count6;
                    
                }else if("july".equals(m1) || "July".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count7 = count7 + x;
                    july1 = count7;
                    
                }else if("august".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count8 = count8 + x;
                    au1 = count8;
                    
                }else if("september".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count9 = count9 + x;
                    se1 = count9;
                    
                }else if("october".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count10 = count10 + x;
                    o1 = count10;
                    
                }else if("november".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count11 = count11 + x;
                    n1 = count11;
                    
                }else if("december".equals(m1)){
                    String newamount = rs.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count12 = count12 + x;
                    d1 = count12;
                    
                }else{}
                
            }
        }catch (SQLException ex) {
            
        }
        
        ObservableList<PieChart.Data> incomePieData = FXCollections.observableArrayList(
                 new PieChart.Data("January",j1),
                 new PieChart.Data("February",f1),
                 new PieChart.Data("March",ma1),
                 new PieChart.Data("April",a1),
                 new PieChart.Data("May",may1),
                 new PieChart.Data("June",ju1),
                 new PieChart.Data("July",july1),
                 new PieChart.Data("August",au1),
                 new PieChart.Data("September",se1),
                 new PieChart.Data("October",o1),
                 new PieChart.Data("November",n1),
                 new PieChart.Data("December",d1));
        
        incomePieChart.setData(incomePieData);
        incomePieChart.setStartAngle(90);
    }
    
    private void expensePie(){
        dataBaseHandler databasehandler2 = dataBaseHandler.getInstance();
	String qu2 = "SELECT * FROM EXPENSE";
	ResultSet rs2 = databasehandler2.execQuery(qu2);
	
        int count1 = 0;
        int count2 = 0;
        int count3 = 0;
        int count4 = 0;
        int count5 = 0;
        int count6 = 0;
        int count7 = 0;
        int count8 = 0;
        int count9 = 0;
        int count10 = 0;
        int count11 = 0;
        int count12 = 0;
        
        try{
            while(rs2.next()) {
                String m1 = rs2.getString("edate");
                if("january".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count1 = count1 + x;
                    ej1 = count1;
                    
                }else if("february".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count2 = count2 + x;
                    ef1 = count2;
                    
                }else if("march".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count3 = count3 + x;
                    ema1 = count3; 
                    
                }else if("april".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count4 = count4 + x;
                    ea1 = count4;
                    
                }else if("may".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count5 = count5 + x;
                    emay1 = count5;
                    
                }else if("june".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count6 = count6 + x;
                    eju1 = count6;
                    
                }else if("july".equals(m1) || "July".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count7 = count7 + x;
                    ejuly1 = count7;
                    
                }else if("august".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count8 = count8 + x;
                    eau1 = count8;
                    
                }else if("september".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count9 = count9 + x;
                    ese1 = count9;
                    
                }else if("october".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count10 = count10 + x;
                    eo1 = count10;
                    
                }else if("november".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count11 = count11 + x;
                    en1 = count11;
                    
                }else if("december".equals(m1)){
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count12 = count12 + x;
                    ed1 = count12;
                    
                }else{}
                
            }
        }catch (SQLException ex) {
            
        }
        
        ObservableList<PieChart.Data> expensesPieData
                =FXCollections.observableArrayList(
                 new PieChart.Data("January",ej1),
                 new PieChart.Data("February",ef1),
                 new PieChart.Data("March",ema1),
                 new PieChart.Data("April",ea1),
                 new PieChart.Data("May",emay1),
                 new PieChart.Data("June",eju1),
                 new PieChart.Data("July",ejuly1),
                 new PieChart.Data("August",eau1),
                 new PieChart.Data("September",ese1),
                 new PieChart.Data("October",eo1),
                 new PieChart.Data("November",en1),
                 new PieChart.Data("December",ed1));
        
        expensePieChart.setData(expensesPieData);
        expensePieChart.setStartAngle(90);
    }
    
    private void totalPie(){
        dataBaseHandler handler1 = dataBaseHandler.getInstance();
	String qu1 = "SELECT * FROM INCOME";
	ResultSet rs1 = handler1.execQuery(qu1);
	int count = 0;
        try{
            while(rs1.next()) {
                    String newamount = rs1.getString("amount");
                    int x = Integer.parseInt(newamount);
                    count = count + x;
            }
        }catch (SQLException ex) {
            
        }
        
        dataBaseHandler handler2 = dataBaseHandler.getInstance();
	String qu2 = "SELECT * FROM EXPENSE";
	ResultSet rs2 = handler2.execQuery(qu2);
	int count1 = 0;	
        try{
            while(rs2.next()) {
                    String newamount = rs2.getString("eamount");
                    int x = Integer.parseInt(newamount);
                    count1 = count1 + x;
            }
        }catch (SQLException ex) {
            
        }

        ObservableList<PieChart.Data> totalPieData
                =FXCollections.observableArrayList(
                 new PieChart.Data("Income",count),
                 new PieChart.Data("Expense",count1));
        
        profitPieChart.setData(totalPieData);
        profitPieChart.setStartAngle(90);

    }

    @FXML
    private void refreshPie(ActionEvent event) {
        incomePieChart.getData().clear();
        expensePieChart.getData().clear();
        profitPieChart.getData().clear();
        
        incomePie();
        expensePie();
        totalPie();
    }
    
}
