
package freport.mark.database;

import freport.mark.listexpenses.ExpensesListController.Expense;
import freport.mark.listincome.IncomeListController.Income;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.PieChart;
import javax.swing.JOptionPane;


public final class dataBaseHandler {
    
    private static dataBaseHandler handler = null;

    private static final String DB_URL = "jdbc:mysql://35.200.129.195/dream";
    private static Connection conn = null;
    private static Statement stmt = null;

    private dataBaseHandler() {
        createConnection();
        setupIncomeTable();
        setupExpenseTable();
    }
    
    public static dataBaseHandler getInstance(){
    
        if(handler == null){
            handler = new dataBaseHandler();
        }
        return handler;
    }
    
     void createConnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            conn = DriverManager.getConnection(DB_URL, "dream","dream@123");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
     
    void setupIncomeTable(){
        String TABLE_NAME = "INCOME";
        try{
            stmt = conn.createStatement();
            
            DatabaseMetaData dbm = conn.getMetaData();
            ResultSet tables = dbm.getTables(null, null, TABLE_NAME.toUpperCase(), null);
            
            if (tables.next()){
                System.out.println("Table " + TABLE_NAME + "already exists. Ready for go!");   
            }else{
                stmt.execute("CREATE TABLE " + TABLE_NAME + "("
                        + "     id varchar(10) primary key,\n"
                        + "     date varchar(10),\n"
                        + "     category varchar(20), \n"
                        + "     amount varchar(20) \n"
                        + " )");
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage() + " ..... setupDatabase");
        } finally {
        }
    }
    
    void setupExpenseTable(){
        String TABLE_NAME = "EXPENSE";
        try{
            stmt = conn.createStatement();
            
            DatabaseMetaData dbm = conn.getMetaData();
            ResultSet tables = dbm.getTables(null, null, TABLE_NAME.toUpperCase(), null);
            
            if (tables.next()){
                System.out.println("Table " + TABLE_NAME + "already exists. Ready for go!");   
            }else{
                stmt.execute("CREATE TABLE " + TABLE_NAME + "("
                        + "     eid varchar(10) primary key,\n"
                        + "     edate varchar(10),\n"
                        + "     ecategory varchar(20), \n"
                        + "     eamount varchar(20) \n"
                        + " )");
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage() + " ... setupDatabase");
        } finally {
        }
    }
    
    
    public ResultSet execQuery(String query) {
        ResultSet result;
        try {
            stmt = conn.createStatement();
            result = stmt.executeQuery(query);
        }
        catch (SQLException ex) {
            System.out.println("Exception at execQuery:dataHandler" + ex.getLocalizedMessage());
            return null;
        }
        finally {
        }
        return result;
    }

    public boolean execAction(String qu) {
        try {
            stmt = conn.createStatement();
            stmt.execute(qu);
            return true;
        }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error:" + ex.getMessage(), "Error Occured", JOptionPane.ERROR_MESSAGE);
            System.out.println("Exception at execQuery:dataHandler" + ex.getLocalizedMessage());
            return false;
        }
        finally {
        }
    }
    public boolean deleteIncome(Income income){
        try {
            String deleteStatement = "DELETE FROM INCOME WHERE ID = ?";
            PreparedStatement stmt = conn.prepareStatement(deleteStatement);
            stmt.setString(1, income.getId());
            int res = stmt.executeUpdate();
            if(res == 1){
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(dataBaseHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean deleteExpense(Expense expense){
        try {
            String deleteStatement = "DELETE FROM EXPENSE WHERE eid = ?";
            PreparedStatement stmt = conn.prepareStatement(deleteStatement);
            stmt.setString(1, expense.getEid());
            int res = stmt.executeUpdate();
            if(res == 1){
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(dataBaseHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean updateIncome(Income income){
        try {
            String update = "UPDATE INCOME SET DATE=?, CATEGORY=?, AMOUNT=? WHERE ID=?";
            PreparedStatement stmt = conn.prepareStatement(update);
            stmt.setString(1, income.getDate());
            stmt.setString(2, income.getCategory());
            stmt.setString(3, income.getAmount());
            stmt.setString(4, income.getId());
            int res = stmt.executeUpdate();
            return (res > 0);
            
        } catch (SQLException ex) {
            Logger.getLogger(dataBaseHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
    
    public boolean updateExpense(Expense expense){
        try {
            String update = "UPDATE EXPENSE SET EDATE=?, ECATEGORY=?, EAMOUNT=? WHERE EID=?";
            PreparedStatement stmt = conn.prepareStatement(update);
            
            stmt.setString(1, expense.getEdate());
            stmt.setString(2, expense.getEcategory());
            stmt.setString(3, expense.getEamount());
            stmt.setString(4, expense.getEid());
            int res = stmt.executeUpdate();
            return (res > 0);
            
        } catch (SQLException ex) {
            Logger.getLogger(dataBaseHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
    //////////////////////////////////////////////////////////////
    public ObservableList<PieChart.Data> getIncomeGraphStatics(){
        ObservableList<PieChart.Data> data = FXCollections.observableArrayList();
        try{
        
            String qu1 = "SELECT COUNT(*) FROM INCOME";
            String qu2 = "SELECT COUNT(*) FROM EXPENSE";
            ResultSet rs = execQuery(qu1);
            if(rs.next()) {
                int count = rs.getInt(1);
                data.add(new PieChart.Data("Total Income (" + count + ")", count));
            }
            rs = execQuery(qu2);
            if(rs.next()) {
                int count = rs.getInt(1);
                data.add(new PieChart.Data("Total Expense (" + count + ")", count));
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        
        return data;
    }
    
}