/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dreamsquad;

import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.transitions.hamburger.HamburgerSlideCloseTransition;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import dreamsquad.FXMLDocumentController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
/**
 * FXML Controller class
 *
 * @author Chann
 */
public class DrawerWindowController implements Initializable {

    @FXML
    private JFXHamburger ham1;
    @FXML
    private ImageView prMng;
    @FXML
    private ImageView CliMng;
    @FXML
    private ImageView EmpMng;
    @FXML
    private ImageView TskMng;
    @FXML
    private ImageView PayCal;
    @FXML
    private ImageView Deadline;
    @FXML
    private ImageView FinR;
    @FXML
    private ImageView PrR;
    @FXML
    private Label text1;


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        hamClick();
        
    }    

    @FXML
    private void taskManagementBtnClicked(MouseEvent event) throws IOException {
        
        
        
    }
    
    private void hamClick(){
    
        HamburgerSlideCloseTransition animation1 = new HamburgerSlideCloseTransition(ham1);
            animation1.setRate(-1);
            ham1.addEventFilter(MouseEvent.MOUSE_CLICKED,(e)->{
                animation1.setRate(animation1.getRate()*-1);
                animation1.play();
                
                
                
            
                
        });
    }

    @FXML
    private void PrMngBtn(MouseEvent event) {
    }

    @FXML
    private void CliMngBtn(MouseEvent event) {
    }

    @FXML
    private void EmpMngBtn(MouseEvent event) {
    }

    @FXML
    private void PayCalBtn(MouseEvent event) throws IOException {
         Parent root = FXMLLoader.load(getClass().getResource("/invoice/main.fxml"));
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
    }

    @FXML
    private void DrsBtn(MouseEvent event) throws IOException {
        
        Parent root = FXMLLoader.load(getClass().getResource("/deadlinereminder/Main.fxml"));
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
        

    }

    @FXML
    private void FinRBtn(MouseEvent event) {
    }

    @FXML
    private void PrRBtn(MouseEvent event) {
    }
    
    
}
